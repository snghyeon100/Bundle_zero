﻿# IUxUI Unique Hit@1 Cases

## 1. pog bundle 17869 (E)
- ranks: IBxBI=3, IUxUI=1, BIxIB=4
- input: 1. 耳钉女气质韩国简约锆石网红纯银耳环甜美雪花水钻耳饰防过敏饰品
- true item: 夏诗文定制 纽扣装饰高腰显瘦半身裙短裙女春款气质百搭纯色A字裙
- IUxUI context: 
- IBxBI top wrong: B. 复古一字领系带薄款亚麻衬衫女 夏季韩版chic气质纯色上衣娃娃衫
- BIxIB top wrong: B. 复古一字领系带薄款亚麻衬衫女 夏季韩版chic气质纯色上衣娃娃衫

## 2. pog bundle 2032 (D)
- ranks: IBxBI=3, IUxUI=1, BIxIB=2
- input: 1. 2019新款短裤女夏季纯棉松紧腰运动宽松裤子阔腿裤休闲裤白色热裤 [Additional context: This item is frequently co-purchased with: 衣品乐原创大码 文艺宽松镂空拼接长袖棉T恤女装早春新款打底上衣.]; 2. 粗跟单鞋女真皮2019春秋英伦风女鞋中跟深口方头加绒单鞋女小皮鞋
- true item: 2019新款真皮女包菱格链条包单肩斜挎包商务小包羊皮小香风包包潮
- IUxUI context: 
- IBxBI top wrong: H. 2018春装新款女装基础款上衣打底衫 纯色休闲百搭圆领短袖T恤女
- BIxIB top wrong: H. 2018春装新款女装基础款上衣打底衫 纯色休闲百搭圆领短袖T恤女

## 3. pog bundle 8102 (B)
- ranks: IBxBI=2, IUxUI=1, BIxIB=2
- input: 1. MASOOMAKE百搭中跟弹力套筒切尔西靴女马丁靴 2018新款秋冬短靴女
- true item: 上品行牛仔裤女冬装2018新款网红同款加绒保暖裤子高腰百搭休闲裤
- IUxUI context: 
- IBxBI top wrong: E. 小谷粒破洞牛仔裤女2017春秋新款韩版学生显瘦高腰chic百搭休闲裤
- BIxIB top wrong: H. 棉服女2018新款冬装韩版中长款过膝大毛领加厚宽松bf棉袄chic外套

## 4. pog bundle 2599 (G)
- ranks: IBxBI=3, IUxUI=1, BIxIB=5
- input: 1. 2019春秋新款真皮单鞋草编厚底松糕乐福鞋女厚底休闲一脚套懒人鞋; 2. 澄心女子原创撞色棉麻大布袋子 超大容量文艺范单肩包长款布包 [Additional context: This item is frequently co-purchased with: 原创日系手工棉麻包亚麻文艺帆布包森系简约大容量休闲单肩包大包; 时差 很仙的上衣洋气春款纯色圆领开衫修身显瘦t恤女长袖单排扣; 可然文书曲/两面穿 雨露棉麻白色衬衫女春装长袖宽松衬衣亚麻上衣.]
- true item: 麻霖文艺态度棉麻女装2019春秋装刺绣羊毛呢中式改良大衣外套女
- IUxUI context: 
- IBxBI top wrong: E. omont蛋挞家 复古学院风休闲宽松高腰格子直筒中裤女阔腿短裤夏季
  - IBxBI wrong context: This item is frequently co-purchased with: FS2019夏季浅灰绿不规则贝壳扣单排扣松紧腰格纹半身裙女中长裙; JHXC时髦气质高领羊羔毛卫衣女加厚2018冬季新款韩版宽松毛绒上衣; 奶兔星球-自制 可爱の猫咪毛衣女v领宽松日系文艺复古开衫小外套.
- BIxIB top wrong: E. omont蛋挞家 复古学院风休闲宽松高腰格子直筒中裤女阔腿短裤夏季
  - BIxIB wrong context: This item is frequently co-purchased with: FS2019夏季浅灰绿不规则贝壳扣单排扣松紧腰格纹半身裙女中长裙; JHXC时髦气质高领羊羔毛卫衣女加厚2018冬季新款韩版宽松毛绒上衣; 奶兔星球-自制 可爱の猫咪毛衣女v领宽松日系文艺复古开衫小外套.

## 5. pog bundle 16824 (B)
- ranks: IBxBI=4, IUxUI=1, BIxIB=6
- input: 1. 双面羊绒大衣女中长款2019新款流行阿尔巴卡羊驼绒羊毛呢外套 [Additional context: This item is frequently co-purchased with: 英伦风双排扣西装外套女中长款宽松休闲网红小西服春秋装2019新款; 梅子熟了文艺高腰波点网纱半身裙复古chic超仙少女裙2019春装新款; 画风 浅蓝色牛仔外套女宽松bf男友风牛仔衣短外套夹克2019春新款.]
- true item: 双面穿！蕾丝裙纱裙 高腰丝绒大摆裙半身裙 网纱百褶A字裙女半裙
- IUxUI context: 
- IBxBI top wrong: D. LOSEA 鳄鱼纹小包包女2018新款铂金凯莉包小手提包百搭单肩斜挎包
  - IBxBI wrong context: This item is frequently co-purchased with: LOSEA 宽肩带斜挎包包女2018新款时尚菱格小方包女复古百搭单肩包; 真皮女包2019新款时尚韩版百搭手提包女气质女神大气单肩斜挎包女; 白色软牛皮单肩包简约百搭小托特包通勤斜跨包文艺小清新真皮女包.
- BIxIB top wrong: D. LOSEA 鳄鱼纹小包包女2018新款铂金凯莉包小手提包百搭单肩斜挎包
  - BIxIB wrong context: This item is frequently co-purchased with: LOSEA 宽肩带斜挎包包女2018新款时尚菱格小方包女复古百搭单肩包; 真皮女包2019新款时尚韩版百搭手提包女气质女神大气单肩斜挎包女; 白色软牛皮单肩包简约百搭小托特包通勤斜跨包文艺小清新真皮女包.

## 6. pog bundle 9504 (F)
- ranks: IBxBI=2, IUxUI=1, BIxIB=2
- input: 1. 劳尔冬季原创简约黑色中长款棉衣日系宽松休闲加厚棉服外套男装; 2. LMTNZD夏季原创休闲灰牛仔衬衫日系宽松复古做旧条纹潮衬衣男上衣
- true item: 黑色牛仔裤男士宽松加肥加大码束脚裤男潮牌春夏款小脚哈伦长裤子
- IUxUI context: 
- IBxBI top wrong: G. 小胡子店2019新款ins工装裤男潮牌束脚休闲裤子小脚九分裤哈伦裤
  - IBxBI wrong context: This item is frequently co-purchased with: 高腰黑色半身裙2019春夏新款中长款开叉绑带不规则OL职业A字裙女; 撞色弹力短靴女粗跟2018韩版新款气质尖头显瘦针织弹力靴切尔西靴; 梅子熟了小清新格子半身裙 复古chic不规则中长款裙子女2019春装.
- BIxIB top wrong: G. 小胡子店2019新款ins工装裤男潮牌束脚休闲裤子小脚九分裤哈伦裤
  - BIxIB wrong context: This item is frequently co-purchased with: 高腰黑色半身裙2019春夏新款中长款开叉绑带不规则OL职业A字裙女; 撞色弹力短靴女粗跟2018韩版新款气质尖头显瘦针织弹力靴切尔西靴; 梅子熟了小清新格子半身裙 复古chic不规则中长款裙子女2019春装.

## 7. pog bundle 18243 (A)
- ranks: IBxBI=2, IUxUI=1, BIxIB=2
- input: 1. GXG男装 男士潮流多色长袖高领套头长袖T恤男#174834140; 2. 炉品工装裤男秋季潮牌宽松潮流束脚裤抽绳多口袋小脚休闲哈伦裤男
- true item: 二十八间冬季街头潮牌个性迷彩男士棉服2018新款休闲宽松连帽棉衣
- IUxUI context: This item is frequently co-purchased with: 二十八间冬装街头潮牌纯色加绒工装束脚裤子ins超火男士休闲长裤; 港风韩风chic复古网红宽松格子高领假两件卫衣男连帽情侣外套男春; 二十八间冬季原创男装嘻哈潮牌高领卡通毛衣男士线衣潮流休闲外套.
- IBxBI top wrong: C. BDCT 日系复古纯色大口袋工装夹克 春季薄款小立领休闲开衫外套潮
- BIxIB top wrong: C. BDCT 日系复古纯色大口袋工装夹克 春季薄款小立领休闲开衫外套潮

## 8. pog bundle 15094 (H)
- ranks: IBxBI=2, IUxUI=1, BIxIB=3
- input: 1. 黑色复古修身羊毛呢外套加厚中长款呢子大衣秋冬季女装20199新款 [Additional context: This item is frequently co-purchased with: 气质修身丝绒长裙OL长袖中长款打底裙连衣裙女装秋装20199新款; 丝绒修身长裙气质名媛收腰显瘦中长款连衣裙女装秋装20199新款; 连体裤女2019夏新款高腰显瘦阔腿短裤韩版宽松碎花度假雪纺连衣裤.]; 2. 鲨鱼皮裤运动打底裤女外穿2018秋新款女士百搭黑色弹力小脚长裤 [Additional context: This item is frequently co-purchased with: shevennie2018秋冬季网红新款厚底小白鞋子 ins运动鞋休闲鞋女鞋; 子晴气质英伦斗篷外套百搭秋冬新款chic宽松女上衣50%羊毛呢大衣; 2019新款女装春装不规则泫雅高腰铅笔小脚裤子紧身网红牛仔裤显瘦.]
- true item: 弹力袜子靴女高跟鞋靴子针织袜靴瘦瘦靴细跟中筒短靴尖头秋冬裸靴
- IUxUI context: This item is frequently co-purchased with: 法式法国复古山本气质桔梗2019早春女春秋赫本裙子过膝红色连衣裙; DIAMOND 2019春款浅色阔腿裤高腰牛仔裤女显瘦百搭宽松直筒裤长裤; 半曲尖头短靴女粗跟靴子女2018新款秋冬瘦瘦高跟网红短靴冬季女鞋.
- IBxBI top wrong: E. 靴子女短靴2018新款秋冬季高跟鞋细跟皮带扣尖头时尚马丁靴及裸靴
- BIxIB top wrong: A. 秋冬季女鞋子2018新款方头平底单鞋韩版百搭加绒毛毛鞋大码女鞋潮

## 9. pog bundle 630 (E)
- ranks: IBxBI=3, IUxUI=1, BIxIB=2
- input: 1. 一字肩小清新白色连衣裙吊带裙女夏学生可爱仙女裙子2019夏装新款; 2. 小瑞靓包银色小方包包迷你女2018新款单肩包时尚斜挎包链条小包包
- true item: 小蜜蜂草帽英伦太阳帽平顶帽大沿帽海边沙滩遮阳防晒度假帽子女夏
- IUxUI context: This item is frequently co-purchased with: 蛋糕裙连衣裙女春秋2019流行网纱裙子高腰中长款仙女裙短袖t恤裙; 日系春夏新款文艺复古休闲棉麻鸭舌帽女南瓜透气八角帽画家帽子潮; 【现货】iuiu阿晶法国爱心印花衬衫裙春装2019款女碎花雪纺连衣裙.
- IBxBI top wrong: D. OXEN潮牌联名简约棒球帽女像素红心春夏遮阳帽子男白色弯檐鸭舌帽
- BIxIB top wrong: F. 雪枫 韩国木质耳环女长款仙气毛球吊坠欧美复古圈圈个性流苏耳线

## 10. pog bundle 7120 (B)
- ranks: IBxBI=5, IUxUI=1, BIxIB=4
- input: 1. 打底裤女冬季加绒2019新款高腰显瘦外穿铅笔小脚黑色杨幂同款裤子; 2. 2019春秋新款黑色高领毛衣女修身显瘦长袖套头纯色针织打底衫 [Additional context: This item is frequently co-purchased with: Studiofun2018秋冬新款 100%纯棉牛仔裤女 深蓝色高腰毛边直筒裤; SINCE THEN度假女夏格子巴厘海岛沙滩裙海边吊带裙长裙 英伦麦田.]
- true item: 波尔谛奇厚底鞋子女2019春季新款休闲运动鞋老爹鞋情侣亲子网红鞋
- IUxUI context: 
- IBxBI top wrong: E. 傲麦粗跟女鞋2019春季新款方头单鞋女百搭小皮鞋一脚蹬乐福鞋两穿
  - IBxBI wrong context: This item is frequently co-purchased with: 奶兔星球-自制 日系直筒工装裤女半松紧腰宽松休闲裤子; 荒荒家小个子chic春季外套风衣中长款冷系女装港风宽松帅气bf上衣; 高腰牛仔裤女阔腿裤坠感长裤女款原宿bf时尚宽松直筒裤子2019春款.
- BIxIB top wrong: G. 华祺迪雅斯2018新款派克大衣韩版大毛领内胆皮草女外套棉服定制
  - BIxIB wrong context: This item is frequently co-purchased with: 欧洲风格站春秋新款尖头系带复古短靴真皮低跟英伦单靴女靴子裸靴; 直击人心的明媚！印花真丝衬衫 du家设计师原创手绘稿花色衬衣; FAN 2018夏季新品小仙女看过来 天丝木耳边泡泡袖上衣（送裹胸）.

## 11. pog bundle 19995 (F)
- ranks: IBxBI=4, IUxUI=1, BIxIB=2
- input: 1. St&amp;Sat/星期六春秋新款原宿平底休闲运动女单鞋小白鞋2558
- true item: 三彩2018春装新款不规则毛边裤微喇叭裤子修身显瘦牛仔长裤子女
- IUxUI context: 
- IBxBI top wrong: H. ins同款半圆草编包黄草镂空编织包月亮包度假拍照沙滩包手提女包
- BIxIB top wrong: A. GUIJIANG 初秋上衣韩版2018新款长袖宽松蝙蝠袖百搭t恤打底衫女潮

## 12. pog bundle 10578 (D)
- ranks: IBxBI=3, IUxUI=1, BIxIB=2
- input: 1. 森系温暖针织小包包少女2019新款韩版潮时尚单肩包文艺百搭斜挎包 [Additional context: This item is frequently co-purchased with: 【西木汀】小众设计师品牌包水桶包包女2019新款牛皮单肩斜挎手提; 平底单鞋浅口百搭低跟瓢鞋2019春季乐福鞋女蝴蝶结学生复古晚晚鞋; 梅子熟了很仙的法国小众桔梗裙复古仙女吊带裙子山本连衣裙过膝夏.]; 2. MG小象格子衬衫女2019新款潮心机小清新娃娃衫上衣设计感短袖衬衣 [Additional context: This item is frequently co-purchased with: 2019早春新款宽松套头蓝色马海毛毛衣女羊毛针织衫; MG小象雪纺防晒衣女中长款韩版2019新款夏季开衫防晒服薄款外套潮; MG小象牛仔外套女韩版宽松bf风2019春季新款渐变色休闲夹克上衣潮.]
- true item: 可卡依真皮小白鞋百搭休闲鞋女单鞋2019春款韩国做旧星星脏脏板鞋
- IUxUI context: This item is frequently co-purchased with: 可妮家手袋原创chic宽肩带水桶包大容量韩版单肩简约百搭手提袋女; 鮀品心跳粉帆布鞋韩版ins女鞋子2019潮鞋春季新款韩版ulzzang板鞋; 小白鞋女真皮2019新款韩版透气单鞋平底休闲板鞋潮流做旧星星鞋女.
- IBxBI top wrong: G. CM国货Feiyue飞跃经典男女帆布鞋运动休闲小白鞋8108情侣鞋酷动城
- BIxIB top wrong: E. 丢丢网红chic直筒加厚加绒牛仔裤女秋冬高腰裤子百搭宽松阔腿长裤

## 13. pog bundle 1168 (H)
- ranks: IBxBI=3, IUxUI=1, BIxIB=2
- input: 1. 毛线帽子女潮韩国百搭保暖日系堆堆针织帽秋冬韩版男纯色套头冷帽; 2. 原创森女部落可爱棉服短款面包服chic冬季女棉衣学生韩版ulzzang
- true item: 原创森女部落加绒牛仔裤高腰短裤靴裤潮2018新款女裤秋冬韩版显瘦
- IUxUI context: 
- IBxBI top wrong: J. ins街拍老爹鞋女冬季韩版百搭2018新款加绒超火港味鞋子女运动鞋
- BIxIB top wrong: D. ACSENSE 黑色加绒加厚女运动裤2017冬季新款宽松百搭显瘦休闲裤潮

## 14. pog bundle 14562 (J)
- ranks: IBxBI=7, IUxUI=1, BIxIB=3
- input: 1. 麦渔人2019春夏新款水桶包女包流苏单肩斜挎包牛皮复古简约小迷你 [Additional context: This item is frequently co-purchased with: 小ck女包2019新款时尚夏季小包包女斜挎包真皮水桶包百搭单肩包潮; 树小姐定制 气质牛皮包 包包女包新款2019时尚女包百搭斜挎链条包; 【南风X世界非遗合作限定款】侗族手工刺绣马鞍包2019新款包包女.]; 2. 方头女凉鞋平底低跟交叉带罗马鞋女一字带扣学生罗马凉鞋女夏夹趾 [Additional context: This item is frequently co-purchased with: 真皮百搭小白鞋女2019春款洋气潮鞋休闲网红平底透气板鞋夏款夏季; 拖地阔腿牛仔裤女2019新款春夏薄款宽松高腰直筒复古裤泫雅老爹裤; ins超火网红智熏鞋2019春季新款网面透气小白鞋厚底松糕老爹鞋女.]
- true item: 【阿一】小袖口不走光无袖背心娃娃裙 宽松显瘦A字吊带连衣裙中裙
- IUxUI context: This item is frequently co-purchased with: 小镇姗姗吊带裙法国复古裙山本超仙女裙chic温柔初恋裙子夏连衣裙; 帆布鞋女2019潮鞋春季学生韩版ulzzang板鞋复古港味布鞋小黑鞋子; 麦渔人2019春夏新款水桶包女包流苏单肩斜挎包牛皮复古简约小迷你.
- IBxBI top wrong: C. 2F1S309 2018幸福地素雅致刺绣仙女网纱裙高腰A字半身裙女长裙
- BIxIB top wrong: C. 2F1S309 2018幸福地素雅致刺绣仙女网纱裙高腰A字半身裙女长裙

## 15. pog_dense bundle 9388 (J)
- ranks: IBxBI=2, IUxUI=1, BIxIB=2
- input: 1. 限时7.5折 所有外套都配 百褶抽绳半高领打底针织连衣裙 [Additional context: This item is frequently co-purchased with: 花栗鼠小姐半身裙长裙女2017白色超仙公主裙蓬蓬裙蕾丝纱蛋糕裙; 欧可芮100%羊毛粉色双面呢大衣中长款宽松毛呢赫本风羊绒外套女冬; 女鞋春季2019新款百搭韩版粗跟单鞋中跟懒人乐福鞋女一脚蹬小皮鞋.]; 2. 小跟短靴女2018新款网红百搭方头粗跟冬季加绒及裸靴短筒高跟靴子 [Additional context: This item is frequently co-purchased with: 项链女纯银 潮 网红锁骨链 简约气质百搭吊坠设计小众短款颈链; 防晒衣女2019新款中长款韩版字母宽松bf港风原宿外套薄款防晒服; 丽哥潮牌黑色裤子女2019春秋新款高腰老爹裤宽松显瘦哈伦牛仔裤女.]
- true item: ins网红贝雷帽女春秋韩版日系百搭画家帽黑色英伦八角帽女帽子夏
- IUxUI context: This item is frequently co-purchased with: 流浪包女2019新款渐变链条小香风菱格水桶包小包包斜挎包百搭ins; 特气质出众薄款收腰开叉中长过膝风衣外套春2019春天家Y053; 红色婚鞋女2019新款新娘鞋浅口方扣水钻高跟鞋女细跟亮片尖头单鞋.
- IBxBI top wrong: B. 小包包女2018新款潮韩版夏天夏季百搭迷你小香风菱格链条斜挎小包
  - IBxBI wrong context: This item is frequently co-purchased with: PIGMISS2019春夏新款极简风clasp夹子包复古手提包女真皮单肩女包; DMON 泫雅同款阔腿牛仔裤女春秋高腰微喇宽松显瘦复古直筒喇叭裤; 小包包女2019新款夏季夏天小ck法国小众时尚百搭小香风链条斜挎包.
- BIxIB top wrong: B. 小包包女2018新款潮韩版夏天夏季百搭迷你小香风菱格链条斜挎小包
  - BIxIB wrong context: This item is frequently co-purchased with: PIGMISS2019春夏新款极简风clasp夹子包复古手提包女真皮单肩女包; DMON 泫雅同款阔腿牛仔裤女春秋高腰微喇宽松显瘦复古直筒喇叭裤; 小包包女2019新款夏季夏天小ck法国小众时尚百搭小香风链条斜挎包.

## 16. pog_dense bundle 23312 (C)
- ranks: IBxBI=2, IUxUI=1, BIxIB=3
- input: 1. 【南风】复古流浪包包女2019新款时尚百搭简约女包单肩斜挎链条包 [Additional context: This item is frequently co-purchased with: ZOWZOW呛口小辣椒 法国小众赫本风气质开挂垂感束腰优雅连衣裙; PROD春秋季韩版宽松卫衣女可爱趣味软妹草莓蛋糕卡通 宽松外套; 【南风】黑色菱格小香包链条包2019时尚包包女包单肩包小方包挎包.]; 2. 妙侣2018秋冬款复古平跟chic短靴女平底棉鞋学生后系带弹力马丁靴 [Additional context: This item is frequently co-purchased with: 【南风】车缝线链条包包女2019新款夏季时尚休闲女包单肩包斜挎包; 原创森女部落格子毛呢外套2018新款流行呢子大衣冬季中长款学生系; 卡农自制毛衣女长袖韩版2019春装新款趣味双面毛线针织衫宽松上衣.]
- true item: 文文婷2019新款秋冬高腰显瘦金丝绒裤黑色坠垂感阔腿直筒拖地裤子
- IUxUI context: This item is frequently co-purchased with: 初语春秋季显瘦宽松bf风磨白浅色小脚铅笔裤百搭牛仔裤女ins潮; Danielwellington 丹尼尔惠灵顿dw手表36mm女表进口石英女表; 女人双面羊绒大衣赫本风过膝中长款韩版2018秋冬季新款毛呢子外套.
- IBxBI top wrong: I. 霓霓家 秋冬新款竖条纹针织阔腿裤女 松紧腰宽松休闲裤长裤子女
  - IBxBI wrong context: This item is frequently co-purchased with: 韩国设计师包包宽肩带水桶包女2019新款牛皮单肩斜挎真皮女包; cheeseY法国小众连衣裙两件套2019春新款宽松雪纺温柔长款仙女裙; 恩家汇 毛呢阔腿裤女九分裤2018秋冬新款宽松垂直感高腰休闲裤子.
- BIxIB top wrong: I. 霓霓家 秋冬新款竖条纹针织阔腿裤女 松紧腰宽松休闲裤长裤子女
  - BIxIB wrong context: This item is frequently co-purchased with: 韩国设计师包包宽肩带水桶包女2019新款牛皮单肩斜挎真皮女包; cheeseY法国小众连衣裙两件套2019春新款宽松雪纺温柔长款仙女裙; 恩家汇 毛呢阔腿裤女九分裤2018秋冬新款宽松垂直感高腰休闲裤子.

## 17. pog_dense bundle 11363 (C)
- ranks: IBxBI=4, IUxUI=1, BIxIB=4
- input: 1. 小瑞靓包拼色菱格包包女2019新款简约百搭斜挎包单肩包小包包女包 [Additional context: This item is frequently co-purchased with: 人本厚底小白鞋女春 网面透气运动鞋女 韩版松糕底百搭学生跑步鞋; MG小象皮卡丘联名很仙的法国小众连衣裙2019新款夏流行网纱长裙子; HFresh 真皮手提女包包 女包 新款2019 时尚简约单肩斜挎小方包女.]; 2. JHXC 圆领条纹套头卫衣女薄款显瘦2019春季新款长袖韩版宽松上衣 [Additional context: This item is frequently co-purchased with: ins短款面包服女2018冬季新款韩版宽松bf棒球棉衣外套拼色小棉袄; 老爹鞋女春鞋子2019春季新款网红百搭春款网面透气小熊潮鞋小白鞋; 梅子熟了法式气质吊带连衣裙夏复古过膝仙女长裙chic温柔2019新款.]
- true item: 英伦风小皮鞋女粗跟黑色2018新款秋季学院风复古百搭软妹女鞋单鞋
- IUxUI context: This item is frequently co-purchased with: ins小皮鞋女复古2018秋冬新款网红毛毛鞋女百搭方头粗跟中跟单鞋; 2018新款棉马甲女韩版学生百搭bf宽松立领无袖棉衣马夹外套秋冬; 2018春季新款韩版棒球服女短款宽松bf风开学季外套百搭学生夹克.
- IBxBI top wrong: G. 毛呢灯笼裤女式2018秋冬新款宽松高腰初恋阔腿裤束脚九分休闲裤子
  - IBxBI wrong context: This item is frequently co-purchased with: A7seven 短款工装PU皮衣女秋季2019新款宽松显瘦休闲皮夹克短外套; 2019春季新款中长款碎花百褶黑色吊带连衣裙女海边渡假无袖背心裙; 金大班踏歌2018秋冬季新款复古chic港味A字半身中长高腰伞裙子女.
- BIxIB top wrong: D. 九月陌墨 2019秋季新款女装修身松紧腰牛仔裤 黑色百搭紧身
  - BIxIB wrong context: This item is frequently co-purchased with: 衣品乐原创大码中长款毛衣开衫女装外套2019春季新款宽松针织衫; 素木原创大码 套头T恤背心裙两件套女春秋半高领韩范套装裙LF3288; 素木春装2019款女外套毛绒宽松韩版短款上衣高贵优雅必入的小外套.

## 18. pog_dense bundle 16090 (H)
- ranks: IBxBI=2, IUxUI=1, BIxIB=8
- input: 1. 施华洛世奇GIRLFRIEND手链女款 时尚简约可调手镯首饰配饰; 2. 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110 [Additional context: This item is frequently co-purchased with: 九月陌墨 2019春季新款女装气质收腰风衣外套女 韩版休闲宽松上衣; 仿羊羔绒皮毛一体外套女2018新款冬季新年撞色翻领毛茸茸短款外套; 阔腿裤女秋冬新款卷边加厚针织宽松高腰坠感直筒休闲九分裤子#.]
- true item: 晚安系列温柔少女星星月亮耳钉软妹日常百搭微镶锆石耳环耳饰R877
- IUxUI context: This item is frequently co-purchased with: 2019春装新款很仙的法国小众连衣裙女打底裙宽松娃娃裙chic裙子; Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约; 夏天气质耳环女长款高级感小众耳饰2019新款潮法式清新百搭耳钉.
- IBxBI top wrong: E. 欧美复古个性网红超仙耳饰女长款气质简约几何长方形钻球耳坠耳环
  - IBxBI wrong context: This item is frequently co-purchased with: 2019新款百搭帆布鞋女饼干鞋潮鞋学生韩版ulzzang小脏橘港风板鞋; 法式法国复古山本气质桔梗2019早春女春秋赫本裙子过膝红色连衣裙; 19春季新款中跟高跟鞋女网红鞋尖头性感单鞋女细跟中空亮片宴会鞋.
- BIxIB top wrong: G. 衣服2018新款chic上衣女春 韩版宽松百搭bf原宿风白色ins同款t恤

## 19. pog_dense bundle 1700 (G)
- ranks: IBxBI=2, IUxUI=1, BIxIB=9
- input: 1. 一字带中空单鞋女粗跟凉鞋2019春夏新款百搭显瘦仙女高跟鞋休闲鞋 [Additional context: This item is frequently co-purchased with: 英伦粗跟小短靴女2018秋冬季新款瘦瘦靴中跟平底马丁靴子加绒女鞋; 法式法国复古山本气质桔梗2019早春女春秋赫本裙子过膝红色连衣裙; 2019春款网红单鞋女中跟伴娘鞋尖头小码高跟鞋女31 32 33新款婚鞋.]; 2. 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰 [Additional context: This item is frequently co-purchased with: ccvv女鞋板鞋2019春季新款真皮百搭学生厚底运动休闲老爹小白鞋女; 小瑞靓包小香风菱格链条小方包包女包新款2019时尚百搭单肩斜挎包; 瘦竹竿自制碎花连衣裙女秋冬季红色打底春秋女装2019新款雪纺裙子.]
- true item: Mexican/稻草人女包手提包包女2019新款时尚百搭女式单肩斜挎包潮
- IUxUI context: This item is frequently co-purchased with: 小ck新加坡限定包包女2018新款潮真皮女包时尚潮2019限量包斜挎包; 小优家包包 马鞍包菱格迷你小包包女包新款2019斜挎包百搭链条包; 风衣女中长款2019春新款木香屋韩版端庄大气宽松百搭chic流行外套.
- IBxBI top wrong: F. 夏装2019新款女雪纺连衣裙时尚中长款荷叶袖小清新条纹印花裙子仙
- BIxIB top wrong: F. 夏装2019新款女雪纺连衣裙时尚中长款荷叶袖小清新条纹印花裙子仙

## 20. pog_dense bundle 3941 (G)
- ranks: IBxBI=7, IUxUI=1, BIxIB=4
- input: 1. doodoo包包女2019新款潮时尚女士百搭斜挎单肩手提包简约大气女包 [Additional context: This item is frequently co-purchased with: Michael KorsMK女包杨幂同款Mercer单肩手提包小号锁头方包; 秋天短款刺绣牛仔长袖外套女装春秋季2018新款学生港风上衣秋装女; 洒满日光/自制 复古中长款连帽羊毛开衫女 宽松显瘦针织外套 春新.]; 2. 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110 [Additional context: This item is frequently co-purchased with: 九月陌墨 2019春季新款女装气质收腰风衣外套女 韩版休闲宽松上衣; 仿羊羔绒皮毛一体外套女2018新款冬季新年撞色翻领毛茸茸短款外套; 阔腿裤女秋冬新款卷边加厚针织宽松高腰坠感直筒休闲九分裤子#.]
- true item: 原创春夏新款娃娃领小香风显瘦黑色a字赫本小黑裙复古短袖连衣裙
- IUxUI context: This item is frequently co-purchased with: MUZI定制包包女2019夏季新款韩版百搭时尚磨砂单肩斜跨撞色小方包; 【悦大人】宽肩带徽章牛皮包包女2019新款单肩斜跨小方包真皮女包; 【sheii苏茵茵】超级回馈！新款SW方头方跟弹力短靴女袜子靴.
- IBxBI top wrong: D. 线下-韩都衣舍2018韩版女装夏装新款高腰宽松女牛仔裤OPC8657晽
- BIxIB top wrong: C. 皱皱zhou高腰牛仔短裤夏2019新款chic韩版百搭显瘦破洞阔腿热裤
  - BIxIB wrong context: This item is frequently co-purchased with: 包头凉鞋女性感防水台一字扣高跟鞋女细跟夏2019新款百搭漆皮女鞋; 金大班路过2018冬季新款韩版加绒高腰休闲直筒学生显瘦牛仔裤子女; KUBERAS法式初恋百褶裙 春夏季复古飘带很仙的长袖连衣裙女小清新.

## 21. pog_dense bundle 21923 (C)
- ranks: IBxBI=3, IUxUI=1, BIxIB=4
- input: 1. 一力米灰尖头高跟粗跟短靴女2018新款秋冬季真皮百搭马丁靴女英伦; 2. AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子 [Additional context: This item is frequently co-purchased with: 2019春秋季新款黑色铅笔裤女装网红超高腰小脚牛仔裤加厚收腹显瘦; 聚利时钢带防水女表韩版女士手表女学生简约时尚潮流休闲大气腕表; 夏季蓝白条纹衬衫男长袖韩版宽松很仙的潮流网红薄款衬衣外套ins.]
- true item: 破洞牛仔裤女春夏季2019新款黑色高腰紧身九分裤乞丐显瘦小脚裤子
- IUxUI context: This item is frequently co-purchased with: 重工网纱很仙的半身裙子2019夏季新款垂感夏天高腰大摆仙女裙长裙; 2019韩版春季新款粉色流行oversize港风休闲宽松连帽工装外套女潮; 2019春秋新款白色衬衫小清新女灯笼袖蕾丝中长款泡泡袖设计感上衣.
- IBxBI top wrong: J. 小鹿要飞 秋季新款ins超火的拼接高腰半身裙女中长款不规则网纱裙
  - IBxBI wrong context: This item is frequently co-purchased with: 牛仔裤女高腰弹力九分裤浅色新款修身显瘦直筒裤韩版毛边百搭必备; 梅子熟了很仙的法国小众桔梗裙复古仙女吊带裙子山本连衣裙过膝夏; MG小象雪纺防晒衣女中长款韩版2019新款春季开衫防晒服薄款外套潮.
- BIxIB top wrong: B. Artmi售空下架包包2017新款时尚简约手拎包个性手提包女包小

## 22. pog_dense bundle 19265 (E)
- ranks: IBxBI=2, IUxUI=1, BIxIB=8
- input: 1. 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰 [Additional context: This item is frequently co-purchased with: ccvv女鞋板鞋2019春季新款真皮百搭学生厚底运动休闲老爹小白鞋女; 小瑞靓包小香风菱格链条小方包包女包新款2019时尚百搭单肩斜挎包; 瘦竹竿自制碎花连衣裙女秋冬季红色打底春秋女装2019新款雪纺裙子.]; 2. 亦谷2018春秋装新款宽松纯色灯笼袖针织衫中长款开衫女L182 [Additional context: This item is frequently co-purchased with: 红谷牛皮女包迷你小包包菱格链条包小香风斜挎包女百搭斜跨单肩包; 亦谷2019春装新款中长款印花长袖裙子过膝碎花雪纺连衣裙黑色女; KUBERAS法式初恋百褶裙 春夏季复古飘带很仙的长袖连衣裙女小清新.]
- true item: 亦谷2019春装新款中长款印花长袖裙子过膝碎花雪纺连衣裙黑色女
- IUxUI context: This item is frequently co-purchased with: 梅子熟了长袖雪纺连衣裙法国复古裙山本裙过膝仙女裙2019春秋新款; 梅子熟了 小清新长袖蕾丝连衣裙 法式复古裙超仙女裙2019春装新款; 名媛气质2019春秋新款时尚波西米亚度假收腰印花长袖连衣裙长裙潮.
- IBxBI top wrong: B. 娃娃领连衣裙2018夏季新款女装蓝色小清新宽松显瘦荷叶边直筒裙子
  - IBxBI wrong context: This item is frequently co-purchased with: 九月陌墨 2019秋季新款女装刺绣拼接连衣裙 中长款翻领显瘦长; 小皮鞋女2019春款新款女鞋英伦风韩版百搭温柔仙女风平底春秋单鞋; 九月陌墨 2019夏季新款女装拼接系带牛仔连衣裙 中长款休闲宽松裙.
- BIxIB top wrong: D. MICOCAH 包包 女包 新款2019 法国小众时尚单肩斜挎百搭小方包ins
  - BIxIB wrong context: This item is frequently co-purchased with: 韩都衣舍2019夏装新款女装冷淡风裙子学生气质中长款连衣裙DU8301; 微笑向暖复古系带手钩花毛针织开衫女中长款针织外套2019春装新款; 【南风】宽带水桶包女2019新款百搭包包简约女包单肩包斜挎包大包.

## 23. pog_dense bundle 2287 (H)
- ranks: IBxBI=3, IUxUI=1, BIxIB=4
- input: 1. （下）2019春装新款粉色刺绣拼色圆领短款卫衣女套头宽松运动上衣 [Additional context: This item is frequently co-purchased with: 小皮鞋女秋季2018新款百搭单鞋女鞋平底厚底圆头系带复古英伦鞋女; 牛货！初薇高端定制2019新款头层牛皮链条水桶包手提斜跨真皮女包; 玛玛绨2019春装新款蓝色束脚运动裤女宽松休闲哈伦裤小脚校服裤潮.]; 2. ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲 [Additional context: This item is frequently co-purchased with: 气质女王范s925纯银耳环女冷淡风超仙耳饰精致港风迷你小耳坠耳钉; 皮裙女2018新款pu裙子 韩版时尚开叉百搭高腰半身裙a字裙chic短裙; AGATHA925银小狗闪石心形项链女甜美可爱优雅学生饰品情侣礼物.]
- true item: ELLE女包牛皮斜挎包62140单肩包小包女手机包迷你手提包女包
- IUxUI context: This item is frequently co-purchased with: 牛皮链条小方女包2019新款潮韩版百搭时尚ins迷你单肩斜挎小包包; 连衣裙女秘密盒子 绿荫; HFresh真皮菱格链条包小香风包包 女包 新款2019时尚单肩斜挎包女.
- IBxBI top wrong: F. 莉贝琳冬季加绒弹力紧身牛仔裤女2018新款修身长裤高腰显瘦小脚裤
  - IBxBI wrong context: This item is frequently co-purchased with: 半身裙伊芙丽2019春装新款复古裙子女中长款a字裙网纱百褶裙纱裙; 张贝贝ibell 网红牛仔裤女秋高腰2018新款破洞韩版阔腿休闲长裤; MG小象中长款冬季呢大衣女宽松韩版2018新款学生加厚保暖毛呢外套.
- BIxIB top wrong: F. 莉贝琳冬季加绒弹力紧身牛仔裤女2018新款修身长裤高腰显瘦小脚裤
  - BIxIB wrong context: This item is frequently co-purchased with: 半身裙伊芙丽2019春装新款复古裙子女中长款a字裙网纱百褶裙纱裙; 张贝贝ibell 网红牛仔裤女秋高腰2018新款破洞韩版阔腿休闲长裤; MG小象中长款冬季呢大衣女宽松韩版2018新款学生加厚保暖毛呢外套.

## 24. pog_dense bundle 26446 (H)
- ranks: IBxBI=3, IUxUI=1, BIxIB=3
- input: 1. 【南风】复古流浪包包女2019新款时尚百搭简约女包单肩斜挎链条包 [Additional context: This item is frequently co-purchased with: ZOWZOW呛口小辣椒 法国小众赫本风气质开挂垂感束腰优雅连衣裙; PROD春秋季韩版宽松卫衣女可爱趣味软妹草莓蛋糕卡通 宽松外套; 【南风】黑色菱格小香包链条包2019时尚包包女包单肩包小方包挎包.]; 2. 夏媛XOFF定制2018秋季新品黑白格纹气质名媛粗花呢小香风短外套女
- true item: ins网红贝雷帽女春秋韩版日系百搭画家帽黑色英伦八角帽女帽子夏
- IUxUI context: This item is frequently co-purchased with: 流浪包女2019新款渐变链条小香风菱格水桶包小包包斜挎包百搭ins; 特气质出众薄款收腰开叉中长过膝风衣外套春2019春天家Y053; 红色婚鞋女2019新款新娘鞋浅口方扣水钻高跟鞋女细跟亮片尖头单鞋.
- IBxBI top wrong: C. 芙怡美2019新款金丝绒阔腿裤女春秋宽松坠感高腰显瘦直筒丝绒长裤
  - IBxBI wrong context: This item is frequently co-purchased with: 网红复古很仙的毛衣女冬宽松2019春季新款慵懒风套头百搭洋气上衣; [VNOOK2018冬季新款] 休闲人字纹直筒复合羊毛呢九分裤 女 两色; 子晴 简约韩版棉服外套女冬季新款百搭chic纯色短款宽松棒球服潮.
- BIxIB top wrong: C. 芙怡美2019新款金丝绒阔腿裤女春秋宽松坠感高腰显瘦直筒丝绒长裤
  - BIxIB wrong context: This item is frequently co-purchased with: 网红复古很仙的毛衣女冬宽松2019春季新款慵懒风套头百搭洋气上衣; [VNOOK2018冬季新款] 休闲人字纹直筒复合羊毛呢九分裤 女 两色; 子晴 简约韩版棉服外套女冬季新款百搭chic纯色短款宽松棒球服潮.

## 25. pog_dense bundle 12443 (H)
- ranks: IBxBI=3, IUxUI=1, BIxIB=3
- input: 1. 淑女名媛春款连衣裙女2019新款气质丝绒长袖a字裙小个子穿搭裙子 [Additional context: This item is frequently co-purchased with: 2019冬宽松复古酒红色新年V领港风chic马海毛毛衣灯笼袖针织上衣; 时尚连衣裙女春秋2019新款淑女名媛小个子穿搭白色蕾丝长袖裙子潮; 气质翩翩 温柔针织显瘦中长开衫披肩女春2019新款春天家X332.]; 2. 过膝长靴女显瘦防水台高跟粗跟长筒靴磨砂高筒长靴子冬季加绒女鞋 [Additional context: This item is frequently co-purchased with: 高跟单鞋女2019春季新款尖头小粗跟深口鞋时尚拼色百搭网红女鞋子; 娜娜日记2019春装新款女装上衣连帽chic蓝色短款卫衣套头学生冉; MG小象雪纺连衣裙女2019夏季新款中长款吊带裙子个性宽松chic衬衫.]
- true item: 小优家包包刺绣帆布包呢料链条包女2019新款百搭单肩斜挎包小包包
- IUxUI context: This item is frequently co-purchased with: 裙子仙女超仙森系法式复古山本很仙的法国小众碎花连衣裙甜美过膝; 子晴绣花白色连衣裙女2018春新款名媛中长款喇叭袖重工蕾丝公主裙; izp 黑色显瘦内搭修身半高领长袖打底衫女春秋心机设计感上衣韩版.
- IBxBI top wrong: J. 迪桑娜女包手提包小方包 百搭欧美斜挎包包时尚牛皮单肩包风琴包
  - IBxBI wrong context: This item is frequently co-purchased with: 包臀打底小礼服裙2019春秋装新款修身显瘦黑色内搭紧身连衣裙韩版; 斜挎小黑包chic包包女2018新款潮韩版百搭简约单肩复古港风小方包; 梅子熟了 文艺荷叶边雪纺连衣裙 复古chic仙女初恋裙2019春装新款.
- BIxIB top wrong: J. 迪桑娜女包手提包小方包 百搭欧美斜挎包包时尚牛皮单肩包风琴包
  - BIxIB wrong context: This item is frequently co-purchased with: 包臀打底小礼服裙2019春秋装新款修身显瘦黑色内搭紧身连衣裙韩版; 斜挎小黑包chic包包女2018新款潮韩版百搭简约单肩复古港风小方包; 梅子熟了 文艺荷叶边雪纺连衣裙 复古chic仙女初恋裙2019春装新款.

## 26. pog_dense bundle 2159 (H)
- ranks: IBxBI=2, IUxUI=1, BIxIB=2
- input: 1. S家潮牌夏季裙子两件套法国小众套装裙仙女裙chic温柔纱裙连衣裙 [Additional context: This item is frequently co-purchased with: 白色多层蛋糕裙2019春秋女中长款长裙百褶裙超仙鱼尾裙半身裙裙子; 仙气翩翩白色重工刺绣真丝顺纡乔其连衣裙子夏女2019新春天家X710; ins网红贝雷帽女春秋韩版日系百搭画家帽黑色英伦八角帽女帽子夏.]; 2. 白色软牛皮单肩包简约百搭小托特包通勤斜跨包文艺小清新真皮女包 [Additional context: This item is frequently co-purchased with: 直筒牛仔裤女春夏2019新款韩版学生超火cec裤子显瘦chic微喇女裤; 微笑向暖立领网纱刺绣连衣裙法式复古裙山本少女超仙2019新款女装; 金丝绒阔腿裤女春秋2019新款韩版黑色垂感宽松高腰坠感直筒裤子.]
- true item: ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲
- IUxUI context: This item is frequently co-purchased with: 气质女王范s925纯银耳环女冷淡风超仙耳饰精致港风迷你小耳坠耳钉; 皮裙女2018新款pu裙子 韩版时尚开叉百搭高腰半身裙a字裙chic短裙; AGATHA925银小狗闪石心形项链女甜美可爱优雅学生饰品情侣礼物.
- IBxBI top wrong: D. Artmu阿木春季新款韩版休闲小白鞋女牛皮平底单鞋系带百搭运动鞋
  - IBxBI wrong context: This item is frequently co-purchased with: 星星小脏鞋女2019春款做旧韩国脏脏鞋平底学生休闲板鞋子小白鞋女; iWiNG 日式复古褶皱层次印花半身裙中长款百褶裙碎花裙子女夏新款; 限时7.5折 特适合小个子的复古小翻领人字纹双面呢大衣.
- BIxIB top wrong: D. Artmu阿木春季新款韩版休闲小白鞋女牛皮平底单鞋系带百搭运动鞋
  - BIxIB wrong context: This item is frequently co-purchased with: 星星小脏鞋女2019春款做旧韩国脏脏鞋平底学生休闲板鞋子小白鞋女; iWiNG 日式复古褶皱层次印花半身裙中长款百褶裙碎花裙子女夏新款; 限时7.5折 特适合小个子的复古小翻领人字纹双面呢大衣.

## 27. pog_dense bundle 14060 (I)
- ranks: IBxBI=10, IUxUI=1, BIxIB=8
- input: 1. AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子 [Additional context: This item is frequently co-purchased with: 2019春秋季新款黑色铅笔裤女装网红超高腰小脚牛仔裤加厚收腹显瘦; 聚利时钢带防水女表韩版女士手表女学生简约时尚潮流休闲大气腕表; 夏季蓝白条纹衬衫男长袖韩版宽松很仙的潮流网红薄款衬衣外套ins.]; 2. aza小包包2018新款女包草编ins田园风蝴蝶结藤编包篮子手提斜挎包 [Additional context: This item is frequently co-purchased with: XIAOYOUBAG 鳄鱼纹小方包女2019新款时尚手提包百搭单肩斜挎包潮; 云思木想原创设计师女装2019春夏新款仕女印花中长款吊带连衣裙32; 可然 昙香/碎花棉麻连衣裙文艺宽松中长款裙子新款春装2019款女装.]
- true item: YOMU有目 原宿s925银进口古董娃娃蕾丝花朵珍珠耳环女艺术手作
- IUxUI context: This item is frequently co-purchased with: 短靴女2019新款韩版冬季平底马丁靴女加绒英伦风厚底切尔西单靴女; 马丁靴女2018新款网红瘦瘦靴切尔西短靴平底百搭韩版棉鞋女冬加绒; 法式复古裙过膝春装2019款女装碎花雪纺长裙长款衬衫很仙的连衣裙.
- IBxBI top wrong: A. 皮裙女短裙秋冬2018新款女装韩版时尚高腰口袋ins超火的半身裙潮
  - IBxBI wrong context: This item is frequently co-purchased with: 豹纹加绒两面穿仿羊羔毛外套女宽松加厚夹克大衣短款冬季2018新款.
- BIxIB top wrong: B. 女装秋装2018新款时尚潮 宽松复古花朵慵懒风套头高领毛衣女秋冬
  - BIxIB wrong context: This item is frequently co-purchased with: Meow Ji 喵吉 复古V领长袖渡假裙红裙中长款收腰红色连衣裙女春夏; izp 复古双排扣牛仔风衣女春秋长款过膝2019流行系带收腰翻领外套.
