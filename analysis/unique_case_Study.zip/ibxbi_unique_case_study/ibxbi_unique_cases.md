﻿# IBxBI Unique Hit@1 Cases

## 1. pog bundle 16123 (J)
- ranks: IBxBI=1, IUxUI=4, BIxIB=5
- input: 1. Converse匡威1970s三星标白色高帮低帮男女帆布鞋162056C 162065C [Additional context: This item is frequently included in outfits with: 倔强工作室 夏季潮流多口袋迷彩裤男士小脚哈伦裤宽松休闲九分裤; 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表.]
- true item: 几立|我们的征途是星辰大海呀的t恤 日系圆领双色印花套头短袖男X
- IBxBI context: 
- IUxUI top wrong: C. 小玉酱网红浅色高腰直筒牛仔裤女宽松春秋新款港味复古chic裤子女 [Additional context: This item is frequently included in outfits with: 2019新款小包包斜挎包女包韩版手提包迷你小包复古油蜡牛皮小圆包; 大喜自制卡其色风衣女2018秋季新款宽松显瘦韩版中长款风衣外套; 羊毛帽子加厚贝雷帽女秋冬毛呢英伦画家帽韩版蓓蕾帽纯色日系百搭.]
- BIxIB top wrong: C. 小玉酱网红浅色高腰直筒牛仔裤女宽松春秋新款港味复古chic裤子女 [Additional context: This item is frequently included in outfits with: 2019新款小包包斜挎包女包韩版手提包迷你小包复古油蜡牛皮小圆包; 大喜自制卡其色风衣女2018秋季新款宽松显瘦韩版中长款风衣外套; 羊毛帽子加厚贝雷帽女秋冬毛呢英伦画家帽韩版蓓蕾帽纯色日系百搭.]

## 2. pog bundle 3227 (B)
- ranks: IBxBI=1, IUxUI=3, BIxIB=4
- input: 1. 小白鞋女真皮韩版透气单鞋2018秋款平底休闲板鞋潮流做旧星星鞋女 [Additional context: This item is frequently included in outfits with: A7seven 加绒加厚连帽套头卫衣女冬季韩版宽松显瘦学生绒衫外套潮; JHXC chic羊羔毛皮毛一体外套女加厚2018冬季新款宽松bf夹克上衣; 冬季2018新款茧型连帽棉衣女中长款宽松bf拼接面包服加厚棉袄外套.]
- true item: A7seven 加绒加厚连帽套头卫衣女冬季韩版宽松显瘦学生绒衫外套潮
- IBxBI context: This item is frequently included in outfits with: A7seven 加绒加厚牛仔萝卜裤女冬季韩版宽松显瘦休闲九分裤哈伦裤; 小白鞋女真皮韩版透气单鞋2018秋款平底休闲板鞋潮流做旧星星鞋女; 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包.
- IUxUI top wrong: D. 简佰格ins大容量包包2019新款潮时尚百搭单肩手提斜挎包复古女包 [Additional context: This item is frequently included in outfits with: 裤子女宽松直筒复古秋冬新款女装韩版时尚黑色牛仔裤女九分裤潮款; 春季新款方头乐福鞋女软底单鞋平底低跟简约时尚女鞋英伦小皮鞋潮; 小p良品铺 韩国饼干鞋2019春新款休闲鞋真皮平底小白鞋chic单鞋女.]
- BIxIB top wrong: C. 温柔灯笼袖毛绒绒套头衫仿貂绒毛衣白色针织衫打底上衣女韩版秋冬

## 3. pog bundle 341 (G)
- ranks: IBxBI=1, IUxUI=7, BIxIB=3
- input: 1. 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包 [Additional context: This item is frequently included in outfits with: 百搭基础小白鞋女春秋季2019春款新款网红女鞋韩版平底学生白鞋子; MG小象黑色紧身牛仔裤女春季新款开叉高腰小脚裤学生ulzzang裤子; 衣品乐原创大码提花圆领套头毛衣女宽松加厚针织衫韩版冬装R126.]; 2. 邪恶先生修脸日系纯色棉麻八角帽子女夏季文艺画家复古简约报童帽 [Additional context: This item is frequently included in outfits with: A7seven 直筒牛仔裤女秋季2019新款宽松显瘦复古百搭休闲九分裤子; 牛仔裤女春秋2018新款网红同款裤子 韩版百搭高腰牛仔裤九分裤; 森系花瓣珍珠吊坠耳环长款耳坠 气质韩国简约百搭贝壳ins少女耳饰.]
- true item: 一力米灰秋冬季中跟粗跟圆头马丁靴弹力复古小方跟百搭短筒靴子女
- IBxBI context: This item is frequently included in outfits with: LOVEHEYNEW文艺格子复古甜美少女心日系贝雷帽画家帽2018新款; 【南风】红色车缝线菱格包包女2018新款时尚链条女包单肩包斜跨包; A7seven 直筒牛仔裤女秋季2019新款宽松显瘦复古百搭休闲九分裤子.
- IUxUI top wrong: C. 夏季单肩小包包女士2019上新款潮韩版ins百搭链条斜挎包时尚简约 [Additional context: This item is frequently included in outfits with: 2019新款夏款白色一字带凉鞋女仙女风学生百搭细跟性感网红高跟鞋; 雪纺连衣裙2019新款夏季流行夏天裙子小个子裙子仙女超仙森系学生.]
- BIxIB top wrong: F. 秋季新款韩版港味复古宽松格子chic衬衫女蝴蝶结系带长袖打底上衣 [Additional context: This item is frequently included in outfits with: 秋装2018新款木耳边针织小背心马甲女秋短款外穿无袖内搭毛衣上衣; 【亏本秒杀】12/12/20点开抢 秒杀39元 丝绒名牌包包限时抢; ulzzang高腰针织阔腿裤女秋装2018新款chic直筒裤原宿风休闲长裤.]

## 4. pog bundle 18951 (A)
- ranks: IBxBI=1, IUxUI=5, BIxIB=5
- input: 1. 高跟鞋女2019新款细跟尖头百搭单靴冬季瘦瘦马丁靴春秋款时尚短靴 [Additional context: This item is frequently included in outfits with: MISS FLY韩版高腰显瘦弹力涂层PU皮短裤女夏装2018新款阔腿裤热裤; 刘啦啦 中长款豹纹外套秋女2018新款冬装网红毛衣开衫百搭上衣潮#; 网红贝雷帽子女秋冬天 八角帽英伦报童帽 画家帽韩版日系百搭潮人.]
- true item: 韩国复古豹纹贝雷帽女秋冬百搭港风个性画家帽简约休闲潮蓓蕾帽
- IBxBI context: This item is frequently included in outfits with: 【sheii苏茵茵】超级回馈！新款SW方头方跟弹力短靴女袜子靴; 卫衣2018新款女上衣韩版宽松加绒加厚外套长款过膝卫衣连衣裙秋冬.
- IUxUI top wrong: C. 怒推！加绒加厚打底裤女外穿2018秋冬季新款保暖黑色小脚铅笔裤子
- BIxIB top wrong: J. 瘦竹竿 2018韩国秋季新品两粒扣高腰显瘦裤脚撕边缺口直筒牛仔裤 [Additional context: This item is frequently included in outfits with: 黛西毛衣外套女2018新款秋装几何撞色中长款春秋宽松百搭针织开衫; 【一条腰带】13PLUS流浪共和自制民族编织嬉皮流苏腰封 回馈价; 2018新款方头中跟蝴蝶结单鞋韩版百搭粗跟乐福鞋豆豆鞋小皮鞋女鞋.]

## 5. pog bundle 7017 (I)
- ranks: IBxBI=1, IUxUI=8, BIxIB=7
- input: 1. 上新质感小包包女2019新款chic链条复古小方包迷你百搭单肩斜挎包 [Additional context: This item is frequently included in outfits with: 百搭卷边小圆帽韩版潮秋冬季丸子帽小礼帽女纯色兔毛针织毛线帽子; LUKECSION社交女鞋黑色细跟高跟鞋真皮磨砂尖头浅口职业羊皮单鞋; Givenchy/纪梵希许愿球项链女满天星镶钻锁骨链简约个性60414680.]
- true item: LUKECSION社交女鞋黑色细跟高跟鞋真皮磨砂尖头浅口职业羊皮单鞋
- IBxBI context: This item is frequently included in outfits with: 18春秋新款气质显瘦高腰A字裙加绒加厚百搭长裙黑色修身半身裙女; Givenchy/纪梵希许愿球项链女满天星镶钻锁骨链简约个性60414680; 黄一琳2018春秋新品韩版衬衣白衬衫宽松显瘦长袖喇叭袖V领上衣.
- IUxUI top wrong: C. ZEGL蝴蝶结仿珍珠耳环女气质韩国短款耳坠简约百搭少女心ins耳钉 [Additional context: This item is frequently included in outfits with: 小蜜蜂草帽英伦太阳帽平顶帽大沿帽海边沙滩遮阳防晒度假帽子女夏; GRENDHA夏季 巴西进口立体蝴蝶结甜美 不夹脚平底 凉鞋女孩 百搭; 【南风】羊皮菱格链条包真皮女包2018新款手提包简约大气斜跨包.]
- BIxIB top wrong: D. 短款外套女春季2019新款韩版宽松学生学院风麂皮绒复古chic短外套 [Additional context: This item is frequently included in outfits with: 鹿皮绒半身裙春装女2019新款法式复古包臀一步裙秋冬a字高腰短裙; CHICMILD起妙贩卖/自制高品质羊毛混纺贝雷帽画家帽黑灰白色系; 百搭宽松秋衣外穿上衣春装2019新款女时尚内搭条纹打底衫长袖t恤.]

## 6. pog bundle 5470 (G)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. pp home卫衣女春秋2019新款韩版圆领宽松中长款亮片白色套头上衣; 2. 巴掌家欧洲站重工烫钻高腰牛仔裤女春装2019新款时尚百搭浅色裤子 [Additional context: This item is frequently included in outfits with: 巴掌家欧洲站重工宽松套头慵懒毛衣女白色打底针织衫春装2019新款; 【南风】网红小黑包菱格链条包女2019新款女包单肩斜挎包质感包包; 巴掌家重工钉珠镶钻蕾丝针织衫女装春装慵懒套头毛衣宽松2019新款.]
- true item: 明星同款真皮时尚小白鞋女2019春款内增高系带厚底单鞋麦昆达女鞋
- IBxBI context: 
- IUxUI top wrong: A. 热风2018年新款小清新女士亮钻学生小白鞋系带中口板鞋H13W8102 [Additional context: This item is frequently included in outfits with: Fs 2019夏高腰显瘦不规则毛边白色牛仔半身裙女短裙包裙一步裙子; 原创小众设计师手工布包森女复古文艺棉麻大包单肩包女百搭帆布包.]
- BIxIB top wrong: A. 热风2018年新款小清新女士亮钻学生小白鞋系带中口板鞋H13W8102 [Additional context: This item is frequently included in outfits with: Fs 2019夏高腰显瘦不规则毛边白色牛仔半身裙女短裙包裙一步裙子; 原创小众设计师手工布包森女复古文艺棉麻大包单肩包女百搭帆布包.]

## 7. pog bundle 16273 (C)
- ranks: IBxBI=1, IUxUI=4, BIxIB=3
- input: 1. 冬季棉衣女ins中长款韩版宽松棉袄2018新款加厚潮bf棉服外套冬装 [Additional context: This item is frequently included in outfits with: 皮毛一体雪地靴女冬季欧货短靴2018新款保暖加绒加厚棉鞋白色皮面; 毛球帽子女秋冬韩国狐狸毛球毛线帽休闲百搭亲子帽简约儿童针织帽.]; 2. 秋冬天女士甜美可爱耳朵加厚羊羔毛围巾帽子一体雷锋帽 保暖风雪 [Additional context: This item is frequently included in outfits with: 棉袄女2018新款韩版棉衣学生冬季时尚百搭立领保暖棉服女潮款外套; 针织半身裙女秋冬韩版修身中长款高腰显瘦包臀裙开叉一步裙毛线裙; 韩版chic水桶包女2019新款潮秋冬大容量斜挎包简约百搭单肩大包包.]
- true item: 半身裙女春2019新款高腰chic针织裙a字包臀裙不规则毛线短裙子
- IBxBI context: 
- IUxUI top wrong: J. 厚底增高毛毛鞋女冬外穿一脚蹬2018新款加绒瓢鞋懒人羊羔毛豆豆鞋 [Additional context: This item is frequently included in outfits with: ◆MUGU◆裤子女秋冬2018新款韩版锥形加厚高腰系带针织休闲萝卜裤; 小优家包包流浪包女2019新款上新菱格链条包女包锁扣斜挎包单肩包; 2018冬装新款chic羊羔毛外套女貂绒加厚宽松连帽东大门ins短外套.]
- BIxIB top wrong: F. Daphne/达芙妮女鞋冬季热卖时尚平底圆头侧拉链女棉靴中筒靴 [Additional context: This item is frequently included in outfits with: 耳环 女 S925纯银镶嵌和田玉中长款玉兰花型高端耳饰送给女生礼物; 金利来女包单肩包手提软皮chic包包女2018新款韩版潮大容量斜挎包.]

## 8. pog bundle 14269 (E)
- ranks: IBxBI=1, IUxUI=4, BIxIB=3
- input: 1. MUKOK时尚高领针织上衣女2018秋冬新款针织衫薄修身显瘦打底毛衣; 2. LOSEA 马毛锁扣包包女2018新款时尚小方包女包百搭单肩斜挎小包女 [Additional context: This item is frequently included in outfits with: 针织裙长袖女2019春装新款韩范条纹一字肩修身女人味包臀连衣裙; 狂人宇TT女鞋马衔扣乐福鞋女平底懒人鞋真皮英伦风一脚蹬踩跟单鞋; 韩版秋冬甜美可爱胡须耳朵麻花针织毛线帽 加绒加厚保暖帽.]
- true item: 傲麦小短靴女2018秋新款加绒棉鞋子女冬粗跟网红瘦瘦靴复古马丁靴
- IBxBI context: This item is frequently included in outfits with: 【南风】黑色流浪包女2019新款春季休闲女包小包包女单肩包斜挎包; ZOWZOW 秋冬蝴蝶结针织打底连衣裙羊毛裙宽松款2018呛口小辣椒; 真皮女包2019新款气质高级感包包洋气大容量简约大气手提包斜挎包.
- IUxUI top wrong: C. 高腰半身裙女香影2018春秋装新款时尚气质修身显瘦单排扣直筒裙潮
- BIxIB top wrong: C. 高腰半身裙女香影2018春秋装新款时尚气质修身显瘦单排扣直筒裙潮

## 9. pog bundle 6167 (A)
- ranks: IBxBI=1, IUxUI=3, BIxIB=3
- input: 1. 色璞优雅帽子女夏天日式遮阳帽手工编织渔夫帽旅行防晒草帽太阳帽 [Additional context: This item is frequently included in outfits with: 泡菜的店 侧边绑带设计无袖黑色背带裙 2019春季新款吊带连衣裙女; FILA斐乐手表女士石英表简约时尚复古罗马刻度钢带腕表dw616; 2018夏装新款雪纺连衣裙女温柔裙气质显瘦超仙冷淡风黑色慵懒裙子.]; 2. 网红小包包2019新款潮韩版百搭个性时尚手提小清新少女包单肩斜挎 [Additional context: This item is frequently included in outfits with: 大喜自制2018冬装新款女装复古中长款丝绒半身裙修身百搭A字裙女; 珂卡芙2018春秋季新款圆头粗跟单鞋女系带英伦小皮鞋复古中跟女鞋; 韩都衣舍2018韩版女装春装新款宽松纯色打底衫长袖T恤AA11842玎.]
- true item: 热风春季新款女士小清新蝴蝶结休闲鞋女平底单鞋潮H07W8705
- IBxBI context: 
- IUxUI top wrong: C. Designer Plus 短裙女2019春装新款复古a字粗花呢流苏格子半身裙 [Additional context: This item is frequently included in outfits with: 小个子2019新款春秋流行呢子大衣短款复古黑色毛呢外套女学生森系; 秋冬小包包女2018新款潮韩版百搭斜挎包少女丝绒单肩包时尚手提包; 日系护耳兔绒渔夫帽子女冬天加厚盆帽系带防风保暖帽子潮邪恶先生.]
- BIxIB top wrong: B. 流苏雪纺衬衫女19春季新款喇叭袖毛绒绒气质V领百搭长袖宽松上衣 [Additional context: This item is frequently included in outfits with: 女鞋2018新款浅口时尚马毛单鞋性感细跟小清新尖头韩版高跟鞋潮女; EEKE Studio 金球珍珠耳环女可拆卸调节一款多戴耳钉原创小众耳饰; RIKAROOM 黑色加厚显瘦a字裙中长款裙子秋冬高腰修身毛呢半身裙女.]

## 10. pog bundle 1665 (D)
- ranks: IBxBI=1, IUxUI=4, BIxIB=3
- input: 1. TATA/他她秋撞色系带方跟小黑皮鞋女单鞋2HC84CM7 [Additional context: This item is frequently included in outfits with: 晶咕家韩版网纱金丝绒半身裙秋冬女装中长款纱裙a型高腰百褶裙子; 晶咕定制2018春装新款牛仔衬衫女长袖中长款韩版蓝色宽松衬衣外套.]
- true item: 韩国秋冬天贝雷帽复古画家帽羊毛帽子女韩版冬季休闲百搭蓓蕾帽潮
- IBxBI context: This item is frequently included in outfits with: 2019新款秋冬哑光仿羊皮裤女加绒弹力修身显瘦腿高腰黑色打底长裤; 2018新款马丁靴女英伦风短靴粗跟加绒军靴女靴子女秋冬高跟中筒靴; 小鹿要飞秋冬新款大毛领单排扣红色毛呢外套女中长款过膝呢子大衣.
- IUxUI top wrong: E. 范思蓝恩裤子女2018春新款阔腿裤绑带宽松休闲裤高腰百搭韩版长裤 [Additional context: This item is frequently included in outfits with: 2018新款马丁靴女内增高震地王英伦风冬季百搭超高跟厚底短靴子; 范思蓝恩羊毛呢外套女冬装新款韩版宽松显瘦中长款灰色双面呢大衣.]
- BIxIB top wrong: I. 小狍2018新款西装领毛呢外套女韩版显瘦风衣中长款妮子大衣女 [Additional context: This item is frequently included in outfits with: Sense1991毛毛鞋女一脚蹬平底懒人鞋羊毛穆勒鞋春季单鞋|88522; 秋冬季文艺复古贝雷帽女貂绒帽可调节兔毛画家帽潮纯色毛绒蓓蕾帽; 黑色加绒打底裤九分女小脚裤2017秋冬弹力魔术裤紧身外穿铅笔裤子.]

## 11. pog bundle 15060 (G)
- ranks: IBxBI=1, IUxUI=8, BIxIB=8
- input: 1. Converse/匡威高帮经典帆布鞋常青款101009 101013 102307 101010
- true item: NOTHOMME日系简约小直筒宽松牛仔长裤男款锥形裤浅蓝水洗ifashion
- IBxBI context: This item is frequently included in outfits with: 邦顿抖音网红手表男士2019新款潮简约防水虫洞概念石英表学生男表; 【s o s】Converse匡威1970s高低帮帆布运动板鞋黑144757C142334C; Converse/匡威 1970s三星标黑白复古情侣高低帮休闲帆布鞋142334C.
- IUxUI top wrong: J. 2018春季新款韩版棒球服女短款宽松bf风开学季外套百搭学生夹克 [Additional context: This item is frequently included in outfits with: MOCOchic印花字母纯棉宽松短袖圆领t恤女MA173TEE201; 哥弟女鞋2019春夏新款英伦风百搭小白鞋时尚休闲鞋板鞋女AX12022; 茵曼女鞋18年春做旧小脏鞋女真皮复古韩版百搭小白鞋4881030070.]
- BIxIB top wrong: C. 钱夫人CHINSTUDIO 港风pp home字母套头连帽加绒卫衣女冬宽松外套

## 12. pog bundle 10137 (C)
- ranks: IBxBI=1, IUxUI=2, BIxIB=3
- input: 1. 风衣女中长款衣香丽影2018春秋季新款英伦薄款韩版双排扣春季外套
- true item: 韩都衣舍2019夏装新款女装韩版显瘦毛边直筒九分裤牛仔裤JM7462蒖
- IBxBI context: This item is frequently included in outfits with: 艾斯臣基础小白鞋女休闲真皮单鞋女秋新款平底运动鞋学生韩版百搭; 韩都衣舍2017韩版女装冬装新款bf风宽松chic休闲短款棉衣LZ7280烎; 小白鞋女内增高2018春秋季新款韩版百搭女鞋厚底松糕学生鞋运动鞋.
- IUxUI top wrong: A. Alice W花花家2019初春新款韩版网红破洞高腰牛仔裤女显瘦小脚裤 [Additional context: This item is frequently included in outfits with: 【南风】亮片小方包新款2019时尚链条单肩包斜挎包上新小包包女包; 韩国东大门抽象小众金属耳钉女耳环水滴复古气质耳夹耳坠耳饰1440; 水钻单鞋女2019春季夏款平底仙女浅口一脚蹬方头蝴蝶结韩版豆豆鞋.]
- BIxIB top wrong: A. Alice W花花家2019初春新款韩版网红破洞高腰牛仔裤女显瘦小脚裤 [Additional context: This item is frequently included in outfits with: 【南风】亮片小方包新款2019时尚链条单肩包斜挎包上新小包包女包; 韩国东大门抽象小众金属耳钉女耳环水滴复古气质耳夹耳坠耳饰1440; 水钻单鞋女2019春季夏款平底仙女浅口一脚蹬方头蝴蝶结韩版豆豆鞋.]

## 13. pog bundle 1403 (E)
- ranks: IBxBI=1, IUxUI=2, BIxIB=6
- input: 1. 小瑞靓包 闺蜜包拼色锁扣小方包包女2019新款单肩包斜挎包小包包 [Additional context: This item is frequently included in outfits with: 黄色高跟鞋女2019春秋新款拼接马毛猫跟尖头女鞋中跟百搭5cm单鞋; 一力米灰2018新款秋冬季欧美加绒简约高跟尖头马丁靴子粗跟短靴女; 2019春秋季新款韩版时尚平顶鸭舌帽ulzzang百搭小清新海军帽子女.]; 2. vcruan阿希哥 春秋装长裤美式复古型拼色水洗蓝好搭低腰牛仔裤 [Additional context: This item is frequently included in outfits with: 小瑞靓包复古花朵宽肩带小方包包女2019新款简约百搭单肩包斜挎包; 人本2018新款秋冬加绒平底帆布鞋女 文艺运动保暖小白鞋情侣棉鞋; 泡菜的店 2018冬装新款宽松印花双面穿加厚短款长袖chic棉服女.]
- true item: 妙侣2018秋冬新款平底系带chic小短靴女圆头复古帅气机车马丁靴女
- IBxBI context: This item is frequently included in outfits with: 复古港风手提包女2019新款潮森系斜挎包小包包韩版百搭单肩小方包; 加绒牛仔裤女秋冬新款网红脚口开叉紧身高腰显瘦小脚铅笔裤子#; A7seven 帅气百搭短款牛仔短外套女秋季韩版宽松显瘦休闲夹克衫潮.
- IUxUI top wrong: F. 回力鞋女帆布鞋女鞋2019春夏新款百搭韩版学生爆改帆布鞋小白鞋女 [Additional context: This item is frequently included in outfits with: 2018夏新款chic风高腰阔腿破洞牛仔短裤女网红同款显瘦热裤子港味; 红谷明星同款包包2019新款单肩包大包牛皮手提包女包大容量托特包; 韩都衣舍2018新款女装春装韩版宽松连帽印花chic长袖卫衣KY9536湲.]
- BIxIB top wrong: C. 安妮森林 1705棵树 文艺复古百搭抽褶针织外套开衫春装2018新款女 [Additional context: This item is frequently included in outfits with: 安妮森林秋新款宽松时尚简约休闲裤气质显瘦百搭黑色九分阔腿裤女; essnidel昕薇同款2017新款系带方头小短靴加绒女冬踝靴高跟毛毛鞋.]

## 14. pog bundle 18292 (C)
- ranks: IBxBI=1, IUxUI=4, BIxIB=3
- input: 1. 2018春新款 cachecache 欧美时尚潮流字母印花灯笼袖宽松长袖卫衣; 2. CacheCache春新款棒球服女宽松bf复古港味chic休闲原宿绿色外套女
- true item: 韩国项圈choker项链女锁骨链双层毛衣链简约脖子饰品项圈颈带颈链
- IBxBI context: 
- IUxUI top wrong: H. 珍妮宇航局 城市限定羊城印花卫衣女早秋新款BF风宽松上衣潮 W120
- BIxIB top wrong: D. MUZI定制包包女2019夏季新款韩版百搭斜挎菱格锁扣简约单肩风琴包 [Additional context: This item is frequently included in outfits with: 骆驼女鞋 秋冬短靴 时尚英伦系带靴子平底头层真皮短筒女靴子; MONA 粉色灯芯绒阔腿裤女2018秋季高腰显瘦直筒裤休闲宽松长裤潮; MONA 绿色短袖上衣女2018夏季新款字母宽松显瘦体恤圆领全棉T恤.]

## 15. pog bundle 9539 (D)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 2019春秋季新款高腰网红牛仔裤女膝盖破洞乞丐显瘦紧身小脚九分裤 [Additional context: This item is frequently included in outfits with: shevennie2018新款链条羊皮腰包女小香风斜挎包迷你小包包 女包特; 2018秋冬新款fil小白同款亮闪银色尖头亮片细跟高跟短靴裸靴子女; 秋冬2018新款女靴方头短靴女粗跟chic马丁靴百搭秋款靴子高跟性感.]; 2. ZY喜哥 美到炸~一定要入手！2019新款网红针织开衫女拼色洋气上衣
- true item: 壹克 Tlas&amp;Co 925银镀18K金云朵彩虹耳钉晶钻原创设计耳环女
- IBxBI context: This item is frequently included in outfits with: 包头凉鞋2019新款一字扣法式少女高跟鞋细跟女夏亮片银色伴娘婚鞋; 【Q】女装2019新款气质V领连袖网纱拼接牛仔荷叶边时尚连衣裙k; 上新小包包女2019新款潮韩版百搭斜挎小包亮片链条时尚锁扣小方包.
- IUxUI top wrong: G. 网红简约短款项链黑色颈带脖颈饰品女 choker脖子项圈锁骨链颈链 [Additional context: This item is frequently included in outfits with: 韩国MLB棒球帽男女夏款NY帽子藏蓝可调节遮阳帽休闲鸭舌帽; 日记2018秋装新款针织衫女宽松套头红色条纹上衣V领毛衣女嫤XJ; GLEEE真皮水桶包迷你软链条小包单肩斜跨女包大容量抽绳吊坠小包.]
- BIxIB top wrong: A. 短靴女2018新款秋冬季韩版平底马丁靴女英伦风百搭加绒靴子女学生 [Additional context: This item is frequently included in outfits with: viss金度假搭配 波西米亚复古个性锁骨项链女 欧美项圈 民族风; Goutte.shuiii皮裤女2018新款薄款chic短裤潮a字宽松高腰怪味少女; 包包2019春夏新款小众设计缠绕肩带斜挎包百搭时尚撞色手提水桶包.]

## 16. pog bundle 17347 (G)
- ranks: IBxBI=1, IUxUI=3, BIxIB=2
- input: 1. 哥弟女鞋2019春夏新款真皮厚底增高小白鞋网红松糕休闲板鞋910202 [Additional context: This item is frequently included in outfits with: 法式少女中长裙女2018春装夏新款韩版小清新碎花雪访套装裙两件套; MOCO纯色显瘦微喇叭裤女高腰复古港味九分裤夏紧身牛仔裤; MOCO暗扣烂边长袖V领针织宽松外套MA173CAR308 摩安珂.]
- true item: 欧时纳包包女2019新款潮韩版时尚简约百搭斜挎包单肩小包手提女包
- IBxBI context: This item is frequently included in outfits with: HOZ后街鞋子女潮鞋高帮帆布鞋女韩版隐形内增高女运动鞋小白鞋女; 妖精的口袋上衣春2019新款ulzzang原宿休闲洞洞毛衣镂空针织衫女; ins心机裙子春装2018新款显瘦chic百褶裙原宿a字裙半身裙女J-测试.
- IUxUI top wrong: B. 【南风】纯色牛皮链条包包女2019新款时尚休闲斜挎小包秋冬单肩包 [Additional context: This item is frequently included in outfits with: MG小象加厚棉服女2018新款韩版宽松bf冬季外套时尚蓬蓬短款面包服; JUSTQ冬季新款韩国秒变筷子腿显瘦薄绒牛仔裤女修身百搭九分裤; chic运动鞋女港味鞋子女运动鞋平底休闲高帮鞋女潮鞋冬棉鞋女外穿.]
- BIxIB top wrong: B. 【南风】纯色牛皮链条包包女2019新款时尚休闲斜挎小包秋冬单肩包 [Additional context: This item is frequently included in outfits with: MG小象加厚棉服女2018新款韩版宽松bf冬季外套时尚蓬蓬短款面包服; JUSTQ冬季新款韩国秒变筷子腿显瘦薄绒牛仔裤女修身百搭九分裤; chic运动鞋女港味鞋子女运动鞋平底休闲高帮鞋女潮鞋冬棉鞋女外穿.]

## 17. pog bundle 7282 (G)
- ranks: IBxBI=1, IUxUI=9, BIxIB=6
- input: 1. 夏天高级感包包女百搭小ck限定洋气网红法国小众菱格链条包斜挎包 [Additional context: This item is frequently included in outfits with: 大檐蝴蝶结手工钩针草帽女夏天可折叠出游遮阳帽海边度假沙滩帽子; 钱夫人CHINSTUDIO网红高腰紧身小脚加绒牛仔裤女冬韩版显瘦九分裤; 韩衣女王 秋季飘逸雪纺宽松显瘦绑带裤女高腰阔腿裤子休闲直筒裤.]; 2. 2018新款帆布鞋女鞋学生韩版百搭2019春季爆款运动高帮鞋女春板鞋 [Additional context: This item is frequently included in outfits with: 2018秋冬新款超火网红星星图案中长款黑色慵懒风套头毛衣女宽松; 夏天高级感包包女百搭小ck限定洋气网红法国小众菱格链条包斜挎包; 裙子女秋冬2018新款 韩版高腰毛边不规则针织裙中长款半身裙冬裙.]
- true item: 嘻哈复古水手帽海军帽水兵帽瓜皮帽地主帽无檐棒球帽子潮MIKI HAT
- IBxBI context: This item is frequently included in outfits with: 定制2018冬季新款韩版bf宽松拼接皮毛一体羊羔毛保暖外套女潮外衣; 裙子女秋冬2018新款 韩版高腰毛边不规则针织裙中长款半身裙冬裙; 2018新款帆布鞋女鞋学生韩版百搭2019春季爆款运动高帮鞋女春板鞋.
- IUxUI top wrong: J. 夏季高级感包包女2019新款小ck女包网红质感迷你链条斜挎小包春款 [Additional context: This item is frequently included in outfits with: 毛呢阔腿裤子女2017冬季新款韩版百搭宽松学生ulzzang高腰九分裤; A7seven 韩版简约百搭宽松竹节棉白色长袖T恤女学生休闲打底衫t潮; Hotwind/热风小白鞋女春季白色贝壳头板鞋基础平底百搭学生休闲鞋.]
- BIxIB top wrong: C. 云上生活印花长袖圆领白色T恤女2019春新款韩版宽松百搭上衣T8249 [Additional context: This item is frequently included in outfits with: CHARLES＆KEITH手提包CK2-80270034摩登迷你锯齿装饰单肩包; CHARLES＆KEITH春夏女士单鞋CK1-70580108金属装饰英伦风方跟鞋; 云上生活小个子复古落肩流苏韩版短款牛仔外套W9136.]

## 18. pog_dense bundle 20372 (A)
- ranks: IBxBI=1, IUxUI=4, BIxIB=2
- input: 1. 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品 [Additional context: This item is frequently included in outfits with: contourlines【贝利】牛皮木手提复古包 女链条斜挎包贝壳包新品; RLL随性简约 交叉织系带收腰显瘦中长款珠光质感风衣料连衣裙女春; 一字肩雪纺吊带连衣裙女夏装2018新款中长款气质收腰露肩背带裙子.]; 2. AI 法式特细巴拿马帽手工编织遮阳草帽 春夏优雅爵士男女太阳帽 [Additional context: This item is frequently included in outfits with: 上新小包包女2019新款韩版斜挎包时尚单肩包小清新女包质感小方包; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 唐嫣同款Givenchy/纪梵希项链女新款时尚锁骨链玫瑰金60287913.]
- true item: TEENLADY原创女包欧洲站菱格链条包女小方包斜挎包小包包百搭个性
- IBxBI context: This item is frequently included in outfits with: 短裤女夏2018新款韩版宽松学生百搭超高腰chic显瘦牛仔热裤潮港味; 春夏雪纺连衣裙女2018新款韩版时尚沙滩裙吊带露肩碎花长裙显瘦潮; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品.
- IUxUI top wrong: C. BOCCALOOK定制 秋冬网红过膝毛衣女套头慵懒风宽松高领连衣裙长款 [Additional context: This item is frequently included in outfits with: ins网红贝雷帽女春秋韩版日系百搭画家帽黑色英伦八角帽女帽子夏; 婚鞋女低跟2019新款中跟新娘鞋香槟色礼服伴娘高跟公主婚纱水晶鞋; 【sheii苏茵茵】超级回馈！新款SW方头方跟弹力短靴女袜子靴.]
- BIxIB top wrong: I. 九月陌墨 2019早秋新款女装雪纺拼接连衣裙 中长款休闲显瘦A [Additional context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 帽子女秋冬季贝雷帽女ins英伦羊毛呢女士蓓蕾帽黑色毡帽复古礼帽; 韩版黑色毛呢帽子女秋冬韩国复古小礼帽女英伦名媛时尚百搭爵士帽.]

## 19. pog_dense bundle 21723 (G)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰 [Additional context: This item is frequently included in outfits with: 夏季果冻包2019新款小香风菱格链条PVC透明包包ins超火手提单肩女; 雪纺连衣裙女夏2019新款小清新韩版a字高腰喇叭袖夏天小个子裙子; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.]; 2. 四叶草银手链女手镯韩版简约个性女生礼物镶施华洛世奇锆非 纯银 [Additional context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 欧美新款铆钉金属珠细跟高跟10cm一字带透明黑色性感ins超火凉鞋; 劳士顿正品女士手表女表钨钢防水石英表潮流时尚款2019新款双日历.]
- true item: 法国小众白色凯莉手提限定ck包包女2019新款高级感洋气质感斜挎包
- IBxBI context: This item is frequently included in outfits with: 银超仙永生花瓣流苏显脸瘦适合圆脸的耳环女秋冬新款百搭网红个性; 施华洛世奇 ICONIC SWAN 时尚渐变天鹅手镯手链饰品 送女友礼物; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501.
- IUxUI top wrong: B. CASSILE小香风菱格女包牛皮 2019春夏新款链条休闲单肩斜挎手拿包 [Additional context: This item is frequently included in outfits with: Danielwellington 丹尼尔惠灵顿dw手表女32mm金属编织女表; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 手表女简约大气女士手表女款时尚防水正品女表钢带新款满天星空表.]
- BIxIB top wrong: H. 包包女2019新款韩版斜挎巴黎走秀box小帽箱真皮小圆包单肩手提包 [Additional context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; BettyChow大爱！设计师款羊毛细格子中长款廓形西服外套 18年4; 【MONA】纯色高领毛衣女秋季新款修身显瘦长袖针织打底衫.]

## 20. pog_dense bundle 13961 (D)
- ranks: IBxBI=1, IUxUI=4, BIxIB=2
- input: 1. 红谷夏季包包2018新款潮个性时尚牛皮手提单肩斜挎女包大气戴妃包; 2. 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品 [Additional context: This item is frequently included in outfits with: contourlines【贝利】牛皮木手提复古包 女链条斜挎包贝壳包新品; RLL随性简约 交叉织系带收腰显瘦中长款珠光质感风衣料连衣裙女春; 一字肩雪纺吊带连衣裙女夏装2018新款中长款气质收腰露肩背带裙子.]
- true item: 百丽夏商场同款羊皮女一字扣粗高跟皮凉鞋S7X1DBH8
- IBxBI context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 小包包女2019新款夏天ck时尚简约百搭ins迷你小香风链条斜挎小包.
- IUxUI top wrong: I. 优雅气质撞色大翻领纽扣开叉针织连衣裙 [Additional context: This item is frequently included in outfits with: ZENGLIU双层项链女锁骨链潮网红圆形硬币吊坠短款颈链欧美风饰品; 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰; 迪士尼手表女学生简约韩版潮流防水ulzzang女生大气帆布女士手表.]
- BIxIB top wrong: I. 优雅气质撞色大翻领纽扣开叉针织连衣裙 [Additional context: This item is frequently included in outfits with: ZENGLIU双层项链女锁骨链潮网红圆形硬币吊坠短款颈链欧美风饰品; 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰; 迪士尼手表女学生简约韩版潮流防水ulzzang女生大气帆布女士手表.]

## 21. pog_dense bundle 2115 (D)
- ranks: IBxBI=1, IUxUI=7, BIxIB=2
- input: 1. 阁楼花开秋冬蕾丝连衣裙韩版学生黑色甜美中长款拼接长袖打底衫女; 2. 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子 [Additional context: This item is frequently included in outfits with: 丙夕 2018新款百搭拖鞋一字露趾平底外穿凉拖女拖鞋夏季女鞋罗马; 软牛皮小白鞋系带平底鞋平跟单鞋圆头女鞋缝线银色休闲鞋真皮金色; TATA/他她春季商场同款方头穆勒鞋女凉鞋FI003AH8.]
- true item: honeyGIRL春季真皮女鞋方扣小皮鞋踩脚懒人鞋子平底单鞋女乐福鞋
- IBxBI context: 
- IUxUI top wrong: C. MG小象格子收腰连衣裙女秋新款中长款学院风长袖小清新拼接裙子潮 [Additional context: This item is frequently included in outfits with: 鹿与奈良短靴女秋冬真皮擦色磨砂学院风显瘦韩版皮靴子切尔西靴; 【南风】复古流浪包包女2019新款时尚百搭简约女包单肩斜挎链条包; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]
- BIxIB top wrong: E. 勿上热风2018年女士休闲单鞋圆头小皮鞋女学院风平底鞋H20W8501 [Additional context: This item is frequently included in outfits with: 2019新款韩版中长款宽松大T恤女嘻哈bf短袖ins潮纯棉下衣失踪体恤; 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽; 锁扣小方包包女2019新款百搭时尚豆腐包box单肩斜挎小包/高质版.]

## 22. pog_dense bundle 8502 (B)
- ranks: IBxBI=1, IUxUI=9, BIxIB=4
- input: 1. 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品 [Additional context: This item is frequently included in outfits with: contourlines【贝利】牛皮木手提复古包 女链条斜挎包贝壳包新品; RLL随性简约 交叉织系带收腰显瘦中长款珠光质感风衣料连衣裙女春; 一字肩雪纺吊带连衣裙女夏装2018新款中长款气质收腰露肩背带裙子.]; 2. 夏装2018新款女ins超火性感露肩小心机连衣裙显瘦小香风裙子女夏
- true item: bering白令手表女 防水品牌正品女士手表 钢带小表盘星空女表dw01
- IBxBI context: This item is frequently included in outfits with: Vero Moda新款蝴蝶结收腰牛仔背带A字连衣裙|318242522; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 粗跟一字带网红凉鞋女仙女风ins潮超火2019新款中跟百搭学生时尚.
- IUxUI top wrong: C. BEAU秋季小白鞋女韩版真皮小皮鞋平底休闲鞋女透气舒适板鞋运动鞋 [Additional context: This item is frequently included in outfits with: 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽; S家原创女装秋季2018新款欧美中长款帅气风衣休闲外套女.]
- BIxIB top wrong: I. 2019春季新款百搭黑色少女小清新高跟鞋女细跟尖头红色性感单鞋子 [Additional context: This item is frequently included in outfits with: 红色修身斗篷呢子大衣加厚中长款羊毛呢外套秋冬季女装20199新款; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 麦渔人原创设计包包2018新款宽肩带撞色女包真皮单肩包斜挎小方包.]

## 23. pog_dense bundle 4738 (H)
- ranks: IBxBI=1, IUxUI=7, BIxIB=2
- input: 1. 红谷包包女新款牛皮斜挎包百搭挎包女包小包斜跨单肩包简约小方包 [Additional context: This item is frequently included in outfits with: 范智乔 t恤女夏装2018新款纯色纯棉短袖宽松韩版学生半袖衣服上衣; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 雪纺衫女夏季2018新款格子露肩超仙甜美洋气飘逸小清新衫宽松上衣.]; 2. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]
- true item: 连衣裙秋装女2018新款韩版imiss慵懒风小心机设计感气质pphome裙
- IBxBI context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 2019链条小包包女2018新款百搭斜挎包ins时尚单肩女包小ck2-m200; 显脸瘦的耳环女大耳圈气质韩国个性百搭长款流苏吊坠一款两戴耳坠.
- IUxUI top wrong: F. 红谷包包2019新款个性时尚单肩斜挎手提女包百搭风琴包通勤凯莉包
- BIxIB top wrong: D. 云思木想原创设计师女装2019春夏新款仕女印花中长款吊带连衣裙32 [Additional context: This item is frequently included in outfits with: Danielwellington 丹尼尔惠灵顿dw手表女32mm金属编织女表; 云思木想2019夏装新款女装性感灯笼袖蕾丝衫女打底衫上衣23907.]

## 24. pog_dense bundle 18365 (C)
- ranks: IBxBI=1, IUxUI=2, BIxIB=7
- input: 1. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]; 2. 韩国气质个性简约创意小珍珠滴釉花朵纯银耳钉女百搭耳环耳坠饰品
- true item: 链条包CASSILE 夏季牛皮流苏包欧美时尚双拉链女单肩包斜挎包小
- IBxBI context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; ZENGLIU小众耳夹无耳洞女法式耳钉简约气质冷淡风耳环耳骨夹耳饰.
- IUxUI top wrong: A. 小瑞靓包锁扣小方包包女2019新款时尚百搭单肩斜挎包链条小包女包 [Additional context: This item is frequently included in outfits with: MG小象黑色修身打底裤女时尚外穿微喇叭裤冬季新款不规则高腰裤子; MG小象黑色加绒休闲裤女外穿冬季2018新款学生宽松高腰直筒裤子潮; gshero高腰直筒牛仔裤女春夏卷边小脚裤宽松显瘦九分萝卜老爹裤潮.]
- BIxIB top wrong: F. 林珊珊 2019夏季新款仙女气质温柔裙子蕾丝花边V领提花雪纺连衣裙 [Additional context: This item is frequently included in outfits with: Daphne/达芙妮夏休闲平底女鞋 优雅钻饰珍珠丁字搭扣夹趾凉鞋; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品.]

## 25. pog_dense bundle 6358 (J)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 宾派星空皮带手表女时尚潮流女士手表防水时尚款女2019新款石英表 [Additional context: This item is frequently included in outfits with: 黑眼袋袋包包女士2019夏季新款单肩女包百搭ins斜挎包时尚小包潮; 2019夏装新款百褶裙短裙女黑色半身裙短款小个子高腰裙子夏学生潮; 重工提花复古印花钉钻A型修身背心连衣裙.]; 2. 西遇女鞋2018新款珍珠漆皮休闲小皮鞋平底复古乐福鞋女一脚蹬单鞋 [Additional context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 金狐狸小ck包包女2019新款迷你链条包女包时尚小方包单肩斜挎包潮; 2018新款女装春装韩版假两件雪纺拼接格子连衣裙荷叶边短裙a字裙.]
- true item: 小瑞靓包纯色锁扣小方包包女2018新款欧美时尚斜挎链条包单肩小包
- IBxBI context: This item is frequently included in outfits with: 劳士顿手表女 手链女士手表女款正品女名牌钨钢潮流时尚2018新款; 花花公子女鞋白色厚底运动休闲鞋女内增高旅游跑步鞋韩版小白鞋女; 真美诗秋季羊绒皮水钻方扣粗跟方头高跟单鞋女ZK714CQ7.
- IUxUI top wrong: A. Micocah 包包女 斜挎包 小方包2019新款 单肩手提包简约ins超火 [Additional context: This item is frequently included in outfits with: 欧洲站羊羔毛毛棉鞋女冬季2018新款韩版时尚平底网红加绒豆豆鞋潮; 限时7.5折 半身裙秋女2019新款混搭单品中长款流苏侧开叉半裙; 2018秋季新款百搭韩版网红圆头平底英伦风小皮鞋仙女蝴蝶结单鞋女.]
- BIxIB top wrong: A. Micocah 包包女 斜挎包 小方包2019新款 单肩手提包简约ins超火 [Additional context: This item is frequently included in outfits with: 欧洲站羊羔毛毛棉鞋女冬季2018新款韩版时尚平底网红加绒豆豆鞋潮; 限时7.5折 半身裙秋女2019新款混搭单品中长款流苏侧开叉半裙; 2018秋季新款百搭韩版网红圆头平底英伦风小皮鞋仙女蝴蝶结单鞋女.]

## 26. pog_dense bundle 12057 (E)
- ranks: IBxBI=1, IUxUI=4, BIxIB=7
- input: 1. 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110 [Additional context: This item is frequently included in outfits with: 奢道四叶草项链18k玫瑰金正品彩金黄金黑玛瑙红色玉髓幸运草礼物; 网红耳钉女气质韩国个性潮人简约圆环圆圈大圈圈耳环女纯银耳圈; 红谷包包女2018新款牛皮手提包女包时尚百搭杀手包简约单肩斜挎包.]; 2. 红谷牛皮女包小香风链条包包女新款单肩斜挎包迷你小包百搭小方包 [Additional context: This item is frequently included in outfits with: 巴掌家欧洲站银色半身裙秋冬女装高腰裙子2018新款a字小皮裙短裙; 韩都衣舍2019夏装新款女装桔梗裙网纱套装裙两件套连衣裙OY6198焕; 百丽小白女板鞋春商场同款牛皮拼色休闲平底单鞋BTX21AM8.]
- true item: 巴掌家欧洲站亮片休闲裤黑色束脚裤九分裤子女裤夏季2018新款长裤
- IBxBI context: This item is frequently included in outfits with: 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 【南风】菱格链条包小香风女2018新款单肩小方包包女斜挎包手提包.
- IUxUI top wrong: D. 网红鞋子女2019新款春季英伦方头平底单鞋小皮鞋女韩版百搭乐福鞋 [Additional context: This item is frequently included in outfits with: 包包女包新款2019夏季时尚百搭高级感洋气质感韩版真皮手提斜挎包; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 真丝重工刺绣大码女2019新款高领长袖中长款宽松复古桑蚕丝连衣裙.]
- BIxIB top wrong: F. 碎花雪纺连衣裙夏季2018新款女松紧腰荷叶边V领学生温柔风sukol裙 [Additional context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; XIAOYOUBAG迷你夏天小包包女2019新款上新链条斜挎小包女包百搭潮; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子.]

## 27. pog_dense bundle 24839 (G)
- ranks: IBxBI=1, IUxUI=8, BIxIB=5
- input: 1. 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包 [Additional context: This item is frequently included in outfits with: 粉色加厚中长款棉衣棉服棉袄毛领修身丝绒外套冬季女装20199新款; 钱夫人CHINSTUDIO 港味高腰格子半身裙秋冬女显瘦毛呢裙A字短裙子; 【直降80元】【118元双11限量秒杀】MG小象中长款学生呢子大衣潮.]; 2. 一力米灰2018秋冬季新款英伦圆头切尔西短筒裸靴子高粗跟马丁靴女 [Additional context: This item is frequently included in outfits with: MG小象黑色打底裤女春2019新款休闲紧身裤外穿高腰显瘦小脚九分裤; MG小象2018流行大衣女中长款宽松长袖秋冬新款学生格子毛呢外套潮; 小瑞靓包菱格链条包小香风包包女2019新款单肩斜挎时尚百搭小方包.]
- true item: AI 2019时装周黑马海军帽报童帽 帽子女秋冬欧美贝雷帽百搭鸭舌帽
- IBxBI context: This item is frequently included in outfits with: 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包; 欧美2018新款秋冬超高跟粗跟弹力瘦瘦靴尖头过膝长靴瘦腿长筒女靴; FFAN泛泛 V领法式长袖针织连衣裙女修身秋冬装2018新款打底长裙子.
- IUxUI top wrong: E. 素兮银饰淡水珍珠耳环纯银耳坠女长款气质韩国简约个性百搭耳饰品 [Additional context: This item is frequently included in outfits with: 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子; 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110; 菠萝字母印花翻领系带收腰衬衫裙连衣裙子.]
- BIxIB top wrong: A. &amp;[A605071] 笑涵阁 美貌文艺气！宫廷风一字领喇叭袖针织套头衫 [Additional context: This item is frequently included in outfits with: STPY日韩白色滴油耳钉极简CHIC风复古气质百搭耳环镀真金S925手作; 粗跟单鞋女春秋2019新款女鞋百搭高跟鞋女方头皮鞋深口鞋漆皮女鞋; 【南风】复古锁扣链条包女时尚新款单肩包斜挎包2019百搭包包女包.]

## 28. pog_dense bundle 3900 (I)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 鞋大师2019春新款阿希哥同款复古真皮系带小皮鞋女英伦牛津鞋单鞋; 2. AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子 [Additional context: This item is frequently included in outfits with: 断码清仓 left lady 新款气质女装中长款修身时尚蕾丝拼接连衣裙; 小宜定制 2018秋冬新款韩版毛绒休闲卫衣女宽松加绒连帽厚外套; yihuan韩版铆钉小皮鞋女系带ins单鞋平底黑色复古学院风chic皮鞋.]
- true item: 哈果超人 百褶针织鱼尾裙半身裙女装高腰 中长款秋冬褶皱皱松紧腰
- IBxBI context: 
- IUxUI top wrong: D. 韩国时尚珍珠耳钉女七彩贝珠耳环耳坠首饰品配饰简约耳饰气质网红 [Additional context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 玛玛绨2019春装韩版百搭修身条纹针织衫女套头喇叭袖短款打底毛衣; 凡舒的店 2018新款牛仔短裤女装不规则百搭破洞宽松高腰A字热裤夏.]
- BIxIB top wrong: J. 范智乔 修身V领针织衫女套头长袖秋季薄款上衣韩版毛衣外套 [Additional context: This item is frequently included in outfits with: 原创可爱云朵包手工珍珠lolita毛绒绒学生软妹包 斜挎口金包新品; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 范智乔 时尚网纱半身裙秋中长款少女裙A字裙2018新款女 韩版 百搭.]

## 29. pog_dense bundle 5310 (I)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 【满3件100元】甜美娃娃衫上衣超仙洋气小碎花清新一字露肩雪纺衫 [Additional context: This item is frequently included in outfits with: 斜挎包包2019新款女包韩版百搭单肩包红色贝壳包迷你小包手提包女; 韩国气质红色雪花耳环不对称长款流苏珍珠吊坠纯银耳钉耳坠耳饰品; 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110.]; 2. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]
- true item: 韩国 甜美红色爱心耳环s925纯银针耳钉女防过敏吊坠简约长款气质
- IBxBI context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 嘉里奥小众新款包包女包 真皮链条单肩斜挎包 欧美时尚百搭小方包.
- IUxUI top wrong: G. 拼接马毛女包包2018新款软皮单肩包韩版时尚铆钉手提包百搭斜挎包 [Additional context: This item is frequently included in outfits with: 欧洲站2019春季新款镶水钻板鞋女高帮鞋魔术贴厚底带钻休闲单鞋潮; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 加绒卫裤女秋冬2018新款加厚运动裤高腰宽松束脚哈伦休闲裤棉裤子.]
- BIxIB top wrong: G. 拼接马毛女包包2018新款软皮单肩包韩版时尚铆钉手提包百搭斜挎包 [Additional context: This item is frequently included in outfits with: 欧洲站2019春季新款镶水钻板鞋女高帮鞋魔术贴厚底带钻休闲单鞋潮; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 加绒卫裤女秋冬2018新款加厚运动裤高腰宽松束脚哈伦休闲裤棉裤子.]

## 30. pog_dense bundle 21915 (E)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. TS蹀愫春夏新款玫瑰方扣低跟V口穆勒拖鞋女TA98102-12; 2. EIN言真丝印花连衣裙女装中长款宽松过膝长裙子女春夏2019新款
- true item: 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰
- IBxBI context: This item is frequently included in outfits with: 夏季果冻包2019新款小香风菱格链条PVC透明包包ins超火手提单肩女; 雪纺连衣裙女夏2019新款小清新韩版a字高腰喇叭袖夏天小个子裙子; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.
- IUxUI top wrong: H. EEKE Studio 珍珠耳钉红色晶钻爱心吊坠耳饰高级感复古气质耳环女 [Additional context: This item is frequently included in outfits with: 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包; HYMX潮女鞋街头冬季新款毛毛鞋性感豹纹毛绒绒加绒舒适平底棉单鞋; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]
- BIxIB top wrong: H. EEKE Studio 珍珠耳钉红色晶钻爱心吊坠耳饰高级感复古气质耳环女 [Additional context: This item is frequently included in outfits with: 小瑞靓包菱格链条包包女2019新款软皮手提单肩小包时尚百搭斜挎包; HYMX潮女鞋街头冬季新款毛毛鞋性感豹纹毛绒绒加绒舒适平底棉单鞋; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]

## 31. pog_dense bundle 29294 (J)
- ranks: IBxBI=1, IUxUI=5, BIxIB=2
- input: 1. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]; 2. 2018秋装新款条纹宽松学生衣服长袖T恤女打底衫韩版百搭慵懒上衣
- true item: 韩都衣舍2018新款女装春装韩版修身显瘦小脚铅笔牛仔长裤RW7656瑒
- IBxBI context: This item is frequently included in outfits with: 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲; 衣品乐原创大码中长款韩版休闲条纹外套宽松女装2019春秋装新款.
- IUxUI top wrong: I. 环球ins春季2019新款百搭小白鞋帆布鞋女学生韩版ulzzang秋板鞋 [Additional context: This item is frequently included in outfits with: 上新质感包包女包新款2019韩版时尚ins超火宽肩带单肩百搭斜挎包; ins超火的港味牛仔连衣裙女中长款2018新款长袖绑带复古女人味气; MYTASTE迷你风琴小方包链条包女2018新款百搭简约牛皮单肩斜跨包.]
- BIxIB top wrong: C. 三彩裤子女潮百搭2019春秋装新款显瘦阔腿微喇叭奶奶长裤 [Additional context: This item is frequently included in outfits with: 三彩衬衫女长袖2018春装新款上衣女宽松韩版百搭韩范条纹衬衣潮; 【CEBOSTIN】9号停机坪 0322A1113 复古机车箱子手提牛皮小方包; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品.]

## 32. pog_dense bundle 5664 (F)
- ranks: IBxBI=1, IUxUI=4, BIxIB=2
- input: 1. 欧洲风格站2018秋冬新款女鞋牛皮灯芯绒刺绣平底单鞋小皮鞋洋气款; 2. 朴正义2018秋季新款韩版黑色chic港味一步裙中长款显瘦半身裙子女 [Additional context: This item is frequently included in outfits with: 朴正义 2018冬季新款韩版宽松bf棉服外套加厚短款小棉袄面包服女; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 与格秋季2018新款鳄鱼皮纹星星小脏鞋脏脏鞋休闲运动鞋.]
- true item: ins网红贝雷帽女春秋韩版日系百搭画家帽黑色英伦八角帽女帽子夏
- IBxBI context: This item is frequently included in outfits with: 厚底系带真皮小白鞋女秋冬加绒2018新款单鞋松糕底休闲运动板鞋女; 秋冬女装针织连衣裙中长款长袖连帽卫衣裙子慵懒风宽松毛衣裙长裙; JHXC 慵懒风毛衣开衫外套女宽松2018秋冬新款长袖韩版连帽针织衫.
- IUxUI top wrong: H. 对白2018秋冬新款 字母绣花半高领T恤女 休闲棉质长袖直筒打底衫 [Additional context: This item is frequently included in outfits with: 2017秋冬新款牛仔裤女韩版百搭高腰长裤学生毛边九分裤小脚裤裤子; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.]
- BIxIB top wrong: H. 对白2018秋冬新款 字母绣花半高领T恤女 休闲棉质长袖直筒打底衫 [Additional context: This item is frequently included in outfits with: 2017秋冬新款牛仔裤女韩版百搭高腰长裤学生毛边九分裤小脚裤裤子; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.]

## 33. pog_dense bundle 18195 (A)
- ranks: IBxBI=1, IUxUI=4, BIxIB=2
- input: 1. MG小象白色T恤女短袖闺蜜装夏季纯棉体恤衣服荷叶边不规则上衣潮 [Additional context: This item is frequently included in outfits with: 破洞牛仔短裤女夏高腰港味复古2019新款韩版宽松显瘦学生阔腿裤子; MG小象高腰阔腿裤牛仔短裤女夏2018新款韩版宽松显瘦休闲破洞热裤; 星星月亮珍珠耳环韩国925纯银金色防过敏吊坠日韩气质女名媛甜美.]; 2. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]
- true item: 拉菲斯汀2018新款透明包包女手提袋透明购物袋果冻包女ins超火包
- IBxBI context: This item is frequently included in outfits with: 925纯银圆圈耳环女 韩国气质大圈耳饰法式小众圆环圈圈高级感耳圈; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 【sheii苏茵茵】 致敬！夏季新款马衔扣包头穆勒鞋真皮拖鞋女凉拖.
- IUxUI top wrong: J. 韩国镀18k玫瑰金戒指love项链女锁骨链简约双环指环吊坠情侣饰品 [Additional context: This item is frequently included in outfits with: 古伊萱2018秋新款潮女镶钻獭兔毛毛皮草名媛手提单肩斜挎晚宴包包; 傲麦交叉绑带罗马凉鞋女2019夏季新款百搭粗跟女鞋真皮网红晚晚鞋; 7看了又看 自制系列 超级显瘦又时尚 前开叉设计感针织裤 两色.]
- BIxIB top wrong: F. 秋装女2018新款韩版高腰木耳边宽松牛仔半身裙学生ulzzangA字裙 [Additional context: This item is frequently included in outfits with: 咸鱼共和国丨英伦风复古布洛克风格马丁靴学生学院风黑色小皮鞋女; 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽.]

## 34. pog_dense bundle 14414 (H)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 春款2019重磅真丝桑蚕丝厚长袖衬衫白蓝大飘带蝴蝶结衬衣女; 2. VH2018新款女包真皮大气手提包时尚潮荔枝纹手拎包简约单肩斜挎包
- true item: 烫社交女鞋2019春季新款漆皮裸色单鞋百搭通勤浅口尖头细高跟鞋女
- IBxBI context: This item is frequently included in outfits with: 荔枝纹头层牛皮迷你锁扣凯莉包单肩真皮包手提斜挎Kelly新娘女包; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 2019新款女包韩版ins超火手提包百搭单肩斜挎包夏天风琴小包包潮.
- IUxUI top wrong: D. BT新款乐福鞋女一脚蹬女鞋复古英伦真皮浅口春夏季平底单鞋小皮鞋 [Additional context: This item is frequently included in outfits with: 女包包2019新款潮夏季夏天ck真皮百搭时尚小香风菱格链条斜挎小包; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子; TOPSHOPJAMIE中高腰黑色显瘦修身小脚牛仔裤02Y16HBLK.]
- BIxIB top wrong: D. BT新款乐福鞋女一脚蹬女鞋复古英伦真皮浅口春夏季平底单鞋小皮鞋 [Additional context: This item is frequently included in outfits with: 女包包2019新款潮夏季夏天ck真皮百搭时尚小香风菱格链条斜挎小包; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子; TOPSHOPJAMIE中高腰黑色显瘦修身小脚牛仔裤02Y16HBLK.]

## 35. pog_dense bundle 23812 (I)
- ranks: IBxBI=1, IUxUI=3, BIxIB=2
- input: 1. 【南风】复古流浪包包女2019新款时尚百搭简约女包单肩斜挎链条包 [Additional context: This item is frequently included in outfits with: RACE CHOICE 新款复古设计感醋酸几何手工镀金耳环chic金属风耳饰; 秋冬季马丁靴女2018新款韩版复古粗跟磨砂短靴英伦风真皮系带加绒; 【现货闪发】胖mm大码宽松砖红色牛仔外套女BF风帅气显瘦工装夹克.]; 2. 蜜桃家2019春季韩版bf宽松撞色拼接牛仔外套女士宽松拉链休闲夹克
- true item: 张贝贝ibell 网红牛仔裤女秋高腰2018新款破洞韩版阔腿休闲长裤
- IBxBI context: This item is frequently included in outfits with: ZOWZOW呛口小辣椒大哥廓西新品羊毛双面呢女装长袖休闲西装外套; Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约; 秋装女2018新款领子拼牛仔泰迪熊仿羊羔毛短外套毛毛上衣韩版宽松.
- IUxUI top wrong: J. 仙女包锁扣小方包 包包女2019新款单肩包时尚链条包女斜挎小包女 [Additional context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; YUBUER2019新款修身小心机露背连衣裙女夏温柔风收腰中长款A字裙.]
- BIxIB top wrong: E. 曾小咸 法式复古灯芯绒半身裙秋冬女高腰短裙A字裙显瘦包臀裙 [Additional context: This item is frequently included in outfits with: AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 【令戈工作室】2018新款过膝靴女方头粗跟中跟秋冬弹力高筒长靴子; 梦梦家闺蜜装韩版百搭蝴蝶结系带收腰棉服女冬加厚面包服棉袄外套.]

## 36. pog_dense bundle 22029 (J)
- ranks: IBxBI=1, IUxUI=4, BIxIB=4
- input: 1. 韩都衣舍2019夏新款女装韩版中长款打底裙气质裙子连衣裙OY7321焕 [Additional context: This item is frequently included in outfits with: chic小包包女2019新款潮单肩港风斜挎小方包韩版宽带百搭复古女包; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 思加图夏季平跟小清新休闲海滩女凉鞋9G803BL7.]; 2. 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子 [Additional context: This item is frequently included in outfits with: 丙夕 2018新款百搭拖鞋一字露趾平底外穿凉拖女拖鞋夏季女鞋罗马; 软牛皮小白鞋系带平底鞋平跟单鞋圆头女鞋缝线银色休闲鞋真皮金色; TATA/他她春季商场同款方头穆勒鞋女凉鞋FI003AH8.]
- true item: 2018新款耳钉女个性气质韩国冷淡风耳环网红耳坠睡觉不用摘的耳饰
- IBxBI context: This item is frequently included in outfits with: 牧风 凹造型平顶草帽女夏天蝴蝶结麦秆草帽小清新太阳帽遮阳; 小包包女2018春夏新款潮撞色单肩包韩版链条百搭斜挎包小方包; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.
- IUxUI top wrong: A. 女士凉拖鞋女夏时尚水晶鞋真皮平底一字拖包头半拖鞋尖头水钻皮拖
- BIxIB top wrong: A. 女士凉拖鞋女夏时尚水晶鞋真皮平底一字拖包头半拖鞋尖头水钻皮拖

## 37. pog_dense bundle 10274 (A)
- ranks: IBxBI=1, IUxUI=3, BIxIB=4
- input: 1. 小优家包包女2018新款刺绣香港风复古小方包宽肩带单肩斜挎包女包 [Additional context: This item is frequently included in outfits with: 伯爵猫英伦风小皮鞋女春款百搭单鞋ins日系软妹学生复古马丁鞋女; 一力米灰2018新款冬季真皮马衔扣平底懒人穆勒包头羊毛毛半拖鞋女; 潘司诺女鞋春高贵性感银色奢华水钻满钻防水台超高跟鞋细跟女单鞋.]; 2. Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约 [Additional context: This item is frequently included in outfits with: 何其丑 2019春季新款漆皮中跟白色猫跟鞋女细跟尖头单鞋子; 阿姐家情侣中长款过膝卫衣裙套装女2018秋冬新款连衣裙两件套; 2019春装新款气质时尚拼接花边系带收腰直筒女装蕾丝连衣裙.]
- true item: 2018新款春秋季韩版百搭小尖头网红短靴女粗跟高跟拉链黑色马丁靴
- IBxBI context: This item is frequently included in outfits with: 小优家包包刺绣帆布包呢料链条包女2019新款百搭单肩斜挎包小包包; Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.
- IUxUI top wrong: C. 迷你上新小包包女珐琅蛇头包2019春夏新款网红女包链条单肩斜挎包
- BIxIB top wrong: J. 衣品天成2018冬新款韩版加绒绣花连帽慵懒风卫衣女学生超火的上衣

## 38. pog_dense bundle 27788 (H)
- ranks: IBxBI=1, IUxUI=8, BIxIB=3
- input: 1. chic港风包包女2019新款斜挎包单肩小包网红小黑包复古小方包链条 [Additional context: This item is frequently included in outfits with: 【清仓】靴子女2018冬季加绒粗跟女靴高跟瘦瘦短靴针织袜靴弹力靴; 雪地靴女士短筒两穿2018冬季新款真皮棉靴子厚底防滑短靴保暖加绒; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]; 2. AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子 [Additional context: This item is frequently included in outfits with: 断码清仓 left lady 新款气质女装中长款修身时尚蕾丝拼接连衣裙; 小宜定制 2018秋冬新款韩版毛绒休闲卫衣女宽松加绒连帽厚外套; yihuan韩版铆钉小皮鞋女系带ins单鞋平底黑色复古学院风chic皮鞋.]
- true item: 2018韩版新款粗跟短靴女鞋百搭冬季靴子网红鞋子马丁靴瘦瘦靴女靴
- IBxBI context: This item is frequently included in outfits with: 【5折折扣】修身显瘦牛仔裤女直筒长裤灰色高腰薄绒小脚九分裤; 2018秋新款韩版高腰蕾丝拼接黑色外穿打底裤女弹力紧身百搭小脚裤; 毛线帽子女潮韩国百搭保暖日系堆堆针织帽秋冬韩版男纯色套头冷帽.
- IUxUI top wrong: G. 耳环女2019新款潮韩国个性气质耳饰高级感大气欧美夸张网红耳钉 [Additional context: This item is frequently included in outfits with: K家高腰阔腿裤女长裤2019夏新款宽松显瘦直筒薄款黄色休闲拖地裤; Danielwellington 丹尼尔惠灵顿dw手表女32mm金属编织女表; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.]
- BIxIB top wrong: B. 2017秋冬新款 定制纱线别致版型设计短款针织开衫 安娜家 [Additional context: This item is frequently included in outfits with: 巴掌家欧洲站重工烫钻高腰牛仔裤女春装2019新款时尚百搭浅色裤子; 美嘟嘟定制小众设计简约梯形手提包包女2019新款潮撞色单肩斜挎包; MASOOMAKE街拍皮面小白鞋女秋季2018新款 百搭韩版平底系带板鞋女.]

## 39. pog_dense bundle 18636 (C)
- ranks: IBxBI=1, IUxUI=3, BIxIB=2
- input: 1. 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表 [Additional context: This item is frequently included in outfits with: NOTHOMME夏季日系潮牌卡其色直筒薄款阔腿运动宽松工装休闲裤子男; GENANX闪电潮牌低帮板鞋套脚一脚蹬嘻哈简约英伦休闲青年潮松糕鞋; NOTHOMME日系潮牌假两件纯色衬衫男款简约衬衣街头嘻哈.]; 2. 吃茶去男款蓝标有机棉圆领短袖T恤 白黑素色打底纯色 休闲文艺 [Additional context: This item is frequently included in outfits with: 春季日系清新纯色简约男士修身型长袖纯棉立领牛津纺衬衫休闲衬衣; NOTHOMME日系潮牌宽松版花纱迷彩印花连帽卫衣男款高支灰ifashion; SOARIN英伦复古修身小脚九分裤男 春装薄款纯棉9分裤纯色休闲裤潮.]
- true item: 炉品新款秋季纯色潮牌chic连帽加绒卫衣外套oversize宽松情侣上衣
- IBxBI context: This item is frequently included in outfits with: 吃茶去男款蓝标有机棉圆领短袖T恤 白黑素色打底纯色 休闲文艺; 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表.
- IUxUI top wrong: F. HAVERICE饭馆 裤型狂赞!复古大格子高腰直筒锥型植绒八分格纹裤 [Additional context: This item is frequently included in outfits with: 实现你心愿/网红圆领毛衣女套头2018秋冬新款韩版宽松显瘦针织衫; 韩版半圆马鞍包包女2019冬新款ins网红小黑包质感百搭单肩斜挎包; 豆豆鞋女2019春季新款方头单鞋女平底鞋百搭小皮鞋大码女鞋韩版秋.]
- BIxIB top wrong: F. HAVERICE饭馆 裤型狂赞!复古大格子高腰直筒锥型植绒八分格纹裤 [Additional context: This item is frequently included in outfits with: 实现你心愿/网红圆领毛衣女套头2018秋冬新款韩版宽松显瘦针织衫; 韩版半圆马鞍包包女2019冬新款ins网红小黑包质感百搭单肩斜挎包; 豆豆鞋女2019春季新款方头单鞋女平底鞋百搭小皮鞋大码女鞋韩版秋.]

## 40. pog_dense bundle 16896 (J)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 逸阳女裤2018春新款牛仔裤弹力九分铅笔裤女长裤显瘦小脚裤潮0076; 2. 【微瑕不退换】素木棉麻条纹衬衫大码chic上衣春装衬衣KK3084
- true item: 稻草人女包时尚单肩斜挎包2019新款小清新春款女士小包包百搭夏天
- IBxBI context: This item is frequently included in outfits with: ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽.
- IUxUI top wrong: D. 港风小包包女2018秋冬新款潮磨砂撞色手提包复古百搭斜挎包小方包 [Additional context: This item is frequently included in outfits with: 加绒牛仔裤女秋冬新款网红脚口开叉紧身高腰显瘦小脚铅笔裤子#; 棉马甲女2018新款冬季短款韩版宽松无袖加厚羽绒棉马夹坎肩外套潮; Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约.]
- BIxIB top wrong: D. 港风小包包女2018秋冬新款潮磨砂撞色手提包复古百搭斜挎包小方包 [Additional context: This item is frequently included in outfits with: 加绒牛仔裤女秋冬新款网红脚口开叉紧身高腰显瘦小脚铅笔裤子#; 棉马甲女2018新款冬季短款韩版宽松无袖加厚羽绒棉马夹坎肩外套潮; Mell 马蒂斯人像 小众法式不对称耳环夹女无耳洞高级设计感简约.]

## 41. pog_dense bundle 25830 (I)
- ranks: IBxBI=1, IUxUI=3, BIxIB=2
- input: 1. 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品 [Additional context: This item is frequently included in outfits with: contourlines【贝利】牛皮木手提复古包 女链条斜挎包贝壳包新品; RLL随性简约 交叉织系带收腰显瘦中长款珠光质感风衣料连衣裙女春; 一字肩雪纺吊带连衣裙女夏装2018新款中长款气质收腰露肩背带裙子.]; 2. 很仙的雪纺连衣裙女2019新款法国小众夏天裙子超仙森系仙女长裙夏
- true item: 2019新款夏季百搭仙女风一字带扣凉鞋ins潮透明高跟鞋女细跟透明
- IBxBI context: This item is frequently included in outfits with: Danielwellington 丹尼尔惠灵顿DW手表女28mm简约时尚女表; 红谷小ck包包女2019新款百搭单肩斜挎包牛皮小方包女包复古豆腐包; 范思蓝恩很仙的法国小众雪纺连衣裙女夏显瘦V领通勤法式桔梗裙子.
- IUxUI top wrong: D. 【sheii苏茵茵】超级气质！小辣椒款蝴蝶结浅口尖头中跟单鞋女鞋 [Additional context: This item is frequently included in outfits with: 沈太太S925纯银耳环女气质韩国简约小五角星淡水珍珠贝壳耳坠耳钩; 【南风】复古锁扣链条包女时尚新款单肩包斜挎包2019百搭包包女包.]
- BIxIB top wrong: D. 【sheii苏茵茵】超级气质！小辣椒款蝴蝶结浅口尖头中跟单鞋女鞋 [Additional context: This item is frequently included in outfits with: 沈太太S925纯银耳环女气质韩国简约小五角星淡水珍珠贝壳耳坠耳钩; 【南风】复古锁扣链条包女时尚新款单肩包斜挎包2019百搭包包女包.]

## 42. pog_dense bundle 17687 (B)
- ranks: IBxBI=1, IUxUI=3, BIxIB=4
- input: 1. 2018新款春秋冬平底小短靴女网红切尔西女靴子裸靴女鞋马丁靴瘦瘦; 2. AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子 [Additional context: This item is frequently included in outfits with: 断码清仓 left lady 新款气质女装中长款修身时尚蕾丝拼接连衣裙; 小宜定制 2018秋冬新款韩版毛绒休闲卫衣女宽松加绒连帽厚外套; yihuan韩版铆钉小皮鞋女系带ins单鞋平底黑色复古学院风chic皮鞋.]
- true item: ins超火包小包包女2018新款潮韩版百搭斜挎包复古港风时尚手提包
- IBxBI context: This item is frequently included in outfits with: 秋冬半身裙中长款2018新款黑色高腰针织长裙a字裙大摆裙厚裙子女; 一力米灰2018秋冬季新款简约方头短筒显瘦弹力中跟粗跟马丁短靴女; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.
- IUxUI top wrong: F. 2018冬新款仿羊羔毛驼色泰迪熊毛绒大衣女中长款宽松加厚毛毛外套 [Additional context: This item is frequently included in outfits with: 真皮女包2018新款牛皮大包包女士百搭手提单肩包大包大容量托特包; ins小白鞋女春季百搭基础皮面学生鞋子平底单鞋真皮板鞋女鞋休闲.]
- BIxIB top wrong: A. BINBIN复古名媛气质春装2018新款女长袖蕾丝拼接假两件格子连衣裙 [Additional context: This item is frequently included in outfits with: TS蹀愫春季方扣中跟方头鞋 浅口粗跟单鞋女TA87526-11; 施华洛世奇 HEAR 浪漫心形项链锁骨链女首饰百搭配饰 送女友礼物; 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品.]

## 43. pog_dense bundle 29193 (J)
- ranks: IBxBI=1, IUxUI=5, BIxIB=4
- input: 1. 上新小包包女2018夏天新款潮韩版百搭斜挎单肩链条夹口流苏草编包; 2. 紫琼925纯银天鹅耳钉女气质韩国个性简约百搭耳环冷淡风耳环耳饰
- true item: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501
- IBxBI context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.
- IUxUI top wrong: A. 包包女2019新款CASSILE春小方包时尚女士链条包金属扣单肩斜挎包 [Additional context: This item is frequently included in outfits with: 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 特细出游拉菲草帽子 女士夏韩版 大檐沙滩帽防紫外线遮阳帽可折叠; ZENGLIU小众耳夹无耳洞女法式耳钉简约气质冷淡风耳环耳骨夹耳饰.]
- BIxIB top wrong: C. 短袖拉链系带连帽休闲收腰显瘦气质连衣裙 [Additional context: This item is frequently included in outfits with: 黑眼袋袋包包女士2019夏季新款单肩女包百搭ins斜挎包时尚小包潮; 花花公子板鞋内增高女鞋2019春款透气百搭鞋子女韩版小白鞋女厚底.]

## 44. pog_dense bundle 26319 (F)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501 [Additional context: This item is frequently included in outfits with: 欧洲站2019夏季卡通印花T恤女装中长款宽松大码喇叭袖连衣裙潮牌; 韩国迷你爱心花朵皇冠蝴蝶结耳钉女套装组合日常精致小巧耳饰R973; 韩版可折叠手工大沿草帽女夏天百搭小清新海边沙滩夏防晒遮阳帽子.]; 2. EGGKA高腰a字裙排扣不规则半身裙学生牛仔短裙女2018新款夏季裙子 [Additional context: This item is frequently included in outfits with: 日本潮牌原宿 森系大容量复古单肩帆布包袋 背包大款托特包女包; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501; 耳钉纯银女气质韩国个性简约百搭网红耳环珍珠蓝色爱心防过敏耳饰.]
- true item: 日本潮牌原宿 森系大容量复古单肩帆布包袋 背包大款托特包女包
- IBxBI context: This item is frequently included in outfits with: EGGKA高腰a字裙排扣不规则半身裙学生牛仔短裙女2018新款夏季裙子; 时尚头层牛皮简约百搭棕色白黑色正装西裤腰带女士针扣真皮细皮带; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501.
- IUxUI top wrong: A. 罗绮 2019新款夏韩版学生帆布包 手提大容量购物袋 文艺女包单肩 [Additional context: This item is frequently included in outfits with: chic面包服女短款羽绒棉服韩版2017新款棉袄学生棉衣冬季可爱外套; 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110.]
- BIxIB top wrong: A. 罗绮 2019新款夏韩版学生帆布包 手提大容量购物袋 文艺女包单肩 [Additional context: This item is frequently included in outfits with: chic面包服女短款羽绒棉服韩版2017新款棉袄学生棉衣冬季可爱外套; 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110.]

## 45. pog_dense bundle 1818 (E)
- ranks: IBxBI=1, IUxUI=4, BIxIB=4
- input: 1. 小包包网红春款夏季时尚韩版洋气质感百搭单肩链条学生斜挎女包 [Additional context: This item is frequently included in outfits with: 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽; 下-接吻猫夏新款漆皮时尚粗高跟凉鞋一字带凉鞋女KA87304-14; MG小象阔腿裤女夏2018新款高腰宽松休闲裤黑色九分ulzzang裤子潮.]; 2. 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽 [Additional context: This item is frequently included in outfits with: 圆之 通勤廓形A字半身裙黑色百褶短裙春夏女显瘦; 2017秋低帮真皮运动鞋女小白鞋子韩版休闲平底板鞋女学生球鞋单鞋; ZEGL欧美夸张大圈圈耳环女耳圈气质韩国圆圈耳坠简约百搭个性耳饰.]
- true item: 百思图2018春季新品专柜牛皮猫咪小白鞋休闲鞋板鞋YPQ01AM8
- IBxBI context: This item is frequently included in outfits with: MIUCO女装2018夏季新款吊带裙钉珠刺绣圆领浪漫蕾丝连衣裙两件套; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子; 蝴蝶结仿珍珠耳线耳环女长款吊坠气质韩国简约个性小清新耳坠耳钉.
- IUxUI top wrong: F. 也桃原创简约极简几何线条耳环耳坠饰品925纯银耳勾无耳洞耳夹 [Additional context: This item is frequently included in outfits with: AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子; 剩饭冬装女2018新款中长款漏肩高领毛衣连衣裙港风打底针织毛衣裙; 西木汀牛皮包包女2019新款斜挎蝴蝶结复古马鞍包春季设计师款小众.]
- BIxIB top wrong: B. 【清仓】唐家欧美春装新款女镂空修身A字裙短袖针织连衣裙小黑裙 [Additional context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; 柒妃定制张大奕同款手工编织珍珠包小众设计品牌手提女包.]

## 46. pog_dense bundle 28795 (H)
- ranks: IBxBI=1, IUxUI=4, BIxIB=2
- input: 1. LMTNZD夏季牛仔裤子男士韩版潮流宽松嘻哈港风直筒修身休闲哈伦裤 [Additional context: This item is frequently included in outfits with: LMTNZD夏季字母印花短袖T恤男士 宽松纯棉打底衫潮流韩版半袖上衣; 回力帆布鞋男高帮帆布鞋男鞋子男潮鞋2019新款男鞋夏季透气板鞋男; 天王表男士皮带自动机械手表 商务防水男表品牌正品腕表5844.]; 2. 回力帆布鞋男高帮帆布鞋男鞋子男潮鞋2019新款男鞋夏季透气板鞋男 [Additional context: This item is frequently included in outfits with: 马切达春季男士裤子日系复古哈伦休闲裤宽松束脚卫裤ins运动裤潮; LMTNZD夏季白色短袖男士 T恤字母刺绣休闲纯棉潮流半袖打底衫上衣; LMTNZD夏季条纹短袖男士T恤 圆领宽松韩版复古纯棉海魂衫打底上衣.]
- true item: 天王表男士皮带自动机械手表 商务防水男表品牌正品腕表5844
- IBxBI context: This item is frequently included in outfits with: LMTNZD夏季字母印花短袖T恤男士 韩版宽松纯棉打底衫潮流半袖上衣; GENANX闪电潮牌白色t恤男宽松抽绳松紧下摆七分袖韩版太空棉短袖; 韩版男鞋子春季潮男小白鞋潮流百搭男士休闲潮鞋板鞋2019新款白鞋.
- IUxUI top wrong: A. 马切达春季男装日系复古立领字母刺绣外套青年宽松休闲套头夹克潮 [Additional context: This item is frequently included in outfits with: 春季2019新款男士休闲鞋运动板鞋韩版潮流鞋子百搭黑色皮鞋男夏季; 男道2016秋冬新款原创纯色长袖T恤男日系圆领宽松套头打底衫秋衣; 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表.]
- BIxIB top wrong: A. 马切达春季男装日系复古立领字母刺绣外套青年宽松休闲套头夹克潮 [Additional context: This item is frequently included in outfits with: 春季2019新款男士休闲鞋运动板鞋韩版潮流鞋子百搭黑色皮鞋男夏季; 男道2016秋冬新款原创纯色长袖T恤男日系圆领宽松套头打底衫秋衣; 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表.]

## 47. pog_dense bundle 15733 (E)
- ranks: IBxBI=1, IUxUI=4, BIxIB=3
- input: 1. 复古少女心金箔亚克力耳环女韩国气质长款个性纯银耳坠耳饰R014 [Additional context: This item is frequently included in outfits with: 包包女包新款2019夏季时尚百搭高级感洋气质感韩版真皮手提斜挎包; 小p 良品铺 很好走舒适感人！真皮一字带外穿室外高跟凉鞋女; AIMIGAO爱米高2018早秋新款 羊反绒尖头浅口高跟鞋女铆钉细跟单鞋.]; 2. 春夏裸色粗跟单鞋女英伦中跟一脚蹬小皮鞋方头高跟复古真皮乐福鞋 [Additional context: This item is frequently included in outfits with: [QZ193912AG] 笑涵阁赫本式优雅 风收腰显瘦气质短袖醋酸连衣裙; 上新小包包女2018新款潮韩版丝绒手提小方包秋季百搭单肩包斜挎包; 【南风】复古锁扣链条包女时尚新款单肩包斜挎包2019百搭包包女包.]
- true item: 菱格链条包女2019新款单肩斜挎小包真皮女包手提小方包复古风琴包
- IBxBI context: This item is frequently included in outfits with: 2019春季新款韩版百搭英伦小皮鞋一脚蹬豆豆鞋粗跟方扣单鞋女平底; 复古少女心金箔亚克力耳环女韩国气质长款个性纯银耳坠耳饰R014; 高跟拖鞋女春季2019新款时尚透明韩版外穿包头百搭半拖女网红凉拖.
- IUxUI top wrong: D. 小镇姗姗 一束微光 重工蕾丝气质女神圆领复古圆领收腰连衣裙## [Additional context: This item is frequently included in outfits with: 时尚甜美蝴蝶结耳钉布艺耳环水钻创意气质麻绳珍珠耳坠女韩国耳饰; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子.]
- BIxIB top wrong: D. 小镇姗姗 一束微光 重工蕾丝气质女神圆领复古圆领收腰连衣裙## [Additional context: This item is frequently included in outfits with: 时尚甜美蝴蝶结耳钉布艺耳环水钻创意气质麻绳珍珠耳坠女韩国耳饰; 沙滩帽女巴拿马草帽遮阳帽夏小清新海边海滩帽太阳帽度假防晒帽子.]

## 48. pog_dense bundle 17464 (F)
- ranks: IBxBI=1, IUxUI=2, BIxIB=2
- input: 1. 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表 [Additional context: This item is frequently included in outfits with: NOTHOMME夏季日系潮牌卡其色直筒薄款阔腿运动宽松工装休闲裤子男; GENANX闪电潮牌低帮板鞋套脚一脚蹬嘻哈简约英伦休闲青年潮松糕鞋; NOTHOMME日系潮牌假两件纯色衬衫男款简约衬衣街头嘻哈.]; 2. 二十八间夏季男装欧美街头蝙蝠袖印花短袖潮流宽松纯棉上衣男T恤 [Additional context: This item is frequently included in outfits with: 春季2019新款男士休闲鞋运动板鞋韩版潮流鞋子百搭黑色皮鞋男夏季; 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表.]
- true item: VANS范斯经典款男鞋女鞋黑白低帮Old Skool休闲滑板鞋VN-0D3HY28
- IBxBI context: This item is frequently included in outfits with: 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表; LMTNZD夏季条纹短袖T恤男士复古海军风潮流boy宽松纯棉打底海魂衫; 辰未原创春夏日系牛仔印染好版型简约水洗复古浅色九分牛仔裤男潮.
- IUxUI top wrong: D. KJP珍珠手链女美国进口欧美时尚网红甜美海洋风创意船锚礼物饰品 [Additional context: This item is frequently included in outfits with: 韩国露娜网红仿珍珠耳环 女式气质长款耳坠新款ins耳钉韩版耳饰品; Havaianas巴西2018新品人字拖女凉鞋FREEDOM MAXI米白拖鞋哈瓦那.]
- BIxIB top wrong: E. 回力帆布鞋男低帮男鞋春季2019新款布鞋小白鞋板鞋男鞋子男潮鞋 [Additional context: This item is frequently included in outfits with: 邦顿手表男士机械表全自动防水潮流新概念学生钢皮带中国名牌男表; GBOY夏季复古拼色短裤男青年潮牌水洗绣标中裤日系宽松抽绳沙滩裤.]

## 49. pog_dense bundle 17881 (E)
- ranks: IBxBI=1, IUxUI=9, BIxIB=4
- input: 1. MG小象中长款加厚棉衣女2018冬季新款宽松原宿棉袄学生休闲棉服潮 [Additional context: This item is frequently included in outfits with: MG小象毛呢短裤女春季2019新款黑色高腰外穿宽松显瘦靴裤阔腿裤子; 网红贝雷帽子女秋冬天 八角帽英伦报童帽 画家帽韩版日系百搭潮人; 一力米灰过膝长靴女2018冬季新款尖头高跟粗跟长筒靴弹力显瘦瘦靴.]; 2. 2018冬季新款短筒马丁靴平底女靴网红春秋小短靴女瘦瘦靴粗跟靴子 [Additional context: This item is frequently included in outfits with: 调调家欧洲站2018秋季新款纯色净版百搭款街头PU皮裤薄绒打底裤女; pu皮质八角帽子女秋季英伦潮日系韩版秋冬时尚百搭皮帽鸭舌贝雷帽; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]
- true item: AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子
- IBxBI context: This item is frequently included in outfits with: 断码清仓 left lady 新款气质女装中长款修身时尚蕾丝拼接连衣裙; 小宜定制 2018秋冬新款韩版毛绒休闲卫衣女宽松加绒连帽厚外套; yihuan韩版铆钉小皮鞋女系带ins单鞋平底黑色复古学院风chic皮鞋.
- IUxUI top wrong: D. 街舞运动裤女港风ins超火的嘻哈宽松怪味少女直筒休闲爵士裤子潮 [Additional context: This item is frequently included in outfits with: 天美意2018秋纺织品厚底运动街头风女休闲鞋女鞋99803CM8; 帽子女春夏休闲百搭字母刺绣鸭舌帽米色白色防晒遮阳帽户外棒球帽.]
- BIxIB top wrong: A. 韩国港味宽松高腰阔腿裤女秋季chic松紧直筒西裤长裤灰色休闲裤 [Additional context: This item is frequently included in outfits with: 热风春新款小清新小白鞋女平底原宿鞋系带时尚女休闲鞋潮H14W7110; 2019秋季新款厚款高领长袖T恤女黑色 木耳边喇叭袖打底衫套头修身; 勿上热风秋季学院风甜美女士系带休闲透气鞋圆头小白鞋H14W8501.]

## 50. pog_dense bundle 2786 (H)
- ranks: IBxBI=1, IUxUI=3, BIxIB=2
- input: 1. 【南风】车缝线链条包包女2019新款夏季时尚休闲女包单肩包斜挎包 [Additional context: This item is frequently included in outfits with: 粗跟小皮鞋女2019春季新款英伦复古皮带扣方头方扣女鞋大小码单鞋; 复古少女心金箔亚克力耳环女韩国气质长款个性纯银耳坠耳饰R014; 大喜自制2018夏季新款 圆领无袖蕾丝连衣裙女性感防晒小衫两件套.]; 2. 乌77 花色敲温柔 韩版宽松收腰显瘦绑带中长款雪纺裙蝴蝶袖碎花裙
- true item: 小皮鞋2019春季新款英伦风女鞋豆豆鞋平底春秋韩版乐福鞋单鞋春款
- IBxBI context: This item is frequently included in outfits with: 【南风】车缝线链条包包女2019新款夏季时尚休闲女包单肩包斜挎包; QUEENZZ黑色西装外套女春装2019新款中长款气质收腰西服姚晨同款; ◆SRK◆清甜系淑女 春日印花长裙 蝴蝶结百褶雪纺碎花连衣裙女夏.
- IUxUI top wrong: J. 2019新款单肩风琴包女复古上新时尚宽肩带高级感包包洋气斜挎包女 [Additional context: This item is frequently included in outfits with: 粗跟短靴女2018秋冬新款网红高跟鞋女马丁靴尖头瘦瘦靴加绒靴子女; 安小落坑条交叉斜纹高领打底毛衣女修身秋冬2018新款套头内搭上衣; AI 法式复古贝雷帽 羊毛含量高达90% 秋冬女画家帽毛呢南瓜帽子.]
- BIxIB top wrong: E. 哈森 春季尖头珍珠平跟女鞋 一字扣带中空平底凉鞋 HM76007 [Additional context: This item is frequently included in outfits with: 包包女2019新款夏季夏天小ck真皮时尚百搭仙女休闲斜挎链条小方包; 芭蕾舞女孩显脸瘦的耳环女长款适合圆脸耳坠韩国气质耳钉夸张耳饰; 蓝色蕾丝连衣裙2019新款复古温柔小香风a字裙矮个子女士夏天裙子.]
